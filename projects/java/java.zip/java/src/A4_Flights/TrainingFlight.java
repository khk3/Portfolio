package A4_Flights;

/**
 * A Training Flight has no passengers, and no cargo
 */
public class TrainingFlight extends Flight {

    // TODO-A4 - Complete this class, using javadocs as a reference
    public TrainingFlight(String iFlighNumber, String idayOfWeek, int iDepartureTime, Location iLocation, int iNumCrew) {
        super(iFlighNumber, idayOfWeek, iDepartureTime, iLocation, iNumCrew);

    }

    @Override
    public String getFlightType() {
        return Common.TRAINING;
    }

    public String toDisplayFormat() {
        int crewWeight = this.getNumCrew() * Common.AVERAGE_PERSON_WEIGHT;
        String result = "";
        result += super.toDisplayFormat() + "\tTotal Weight: " + crewWeight;
        return result;
    }

    @Override
    public boolean checkTime() {
        boolean isValid = true;

        if (this.getDepartureTime() < Common.EARLIEST_DEPARTURE || this.getDepartureTime() > Common.LATEST_DEPARTURE) {
            isValid = false;
        }
        return isValid;
    }

    @Override
    public boolean checkPassengers() {
        return true;
    }

    @Override
    public boolean checkWeight() {
        boolean isValid = false;
        if (this.calculateWeight() < Common.MAXIMUM_WEIGHT) {
            isValid = true;
        }
        return isValid;
    }
} // end class TrainingFlight
