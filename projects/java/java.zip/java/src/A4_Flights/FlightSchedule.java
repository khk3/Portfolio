package A4_Flights;

import java.util.ArrayList;

public class FlightSchedule {

    private final Flight[] flights;

    /**
     * Creates a new schedule based on the specified flights.
     *
     * @param flights the flights to be contained in this schedule
     */
    public FlightSchedule(Flight[] flights) {
        this.flights = flights;
    }

    /**
     * Gets all of the flights in this schedule.
     *
     * @return all of the flights in this schedule
     */
    public Flight[] getAllFlights() {
        return flights;
    }

    public Flight[] getFlightsByDestination(String locationCode) {
        // TODO-B1
        // Flight[] allFlights = getAllFlights();

        //Flight[] flightsByDestination;
        //ArrayList<Flight> flightsByDestination = new ArrayList<>();
        int count = countFlightsByDestination(locationCode);

        Flight[] result = new Flight[count];

        int counter = 0;
        for (int i = 0; i < flights.length; i++) {
            if (flights[i].getDestination().getLocationCode().equals(locationCode)) {
                result[counter]= flights[i];
                counter++;
            }
        }

        return result;
    }

    private int countFlightsByDestination(String locationCode) {
        // TODO-B1
        int count = 0;
        for (int i = 0; i < flights.length; i++) {
            if (flights[i].getDestination().getLocationCode().equals(locationCode)) {
                count++;
            }
        }
        return count;
    }

    public Flight[] getFlightsByType(String flightType) {
        // TODO-B2
        int count= countFlightsByType(flightType);
        Flight[]result= new Flight[count];
        
        int counter=0;
        for(int i=0; i<flights.length;i++){
            if(flights[i].getFlightType().equals(flightType))
            {
               result[counter]= flights[i];               
                counter++;
            }       
        }
        return result;
    }

    private int countFlightsByType(String flightType) {
        // TODO-B2
        int count=0;
        for(Flight f: flights){
            if(f.getFlightType().equals(flightType)){
            count++;
            }        
        }
        return count;
    }

} // end class FlightSchedule
