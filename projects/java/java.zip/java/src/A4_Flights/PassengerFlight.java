package A4_Flights;

/**
 * A passenger flight has no cargo
 */
public class PassengerFlight extends Flight {

    // TODO-A3 - Complete this class, using javadocs as a reference
    private int numPassengers;

    public PassengerFlight(String iFlightNumber, String iDayOfWeek, int iDepartureTime, Location iLocation, int iCrewNumber, int iNumPassengers) {
        //super();
        super(iFlightNumber, iDayOfWeek, iDepartureTime, iLocation, iCrewNumber);
        this.numPassengers = iNumPassengers;
    }

    public int getNumPassengers() {
        return this.numPassengers;
    }

    public int calculateWeight() {
        int weightPassengers = this.getNumPassengers() * Common.AVERAGE_PERSON_WEIGHT;
        int weightCrew = super.getNumCrew() * Common.AVERAGE_PERSON_WEIGHT;
        return weightPassengers + weightCrew;
    }

    public String getFlightType() {
        return Common.PASSENGER;
    }

    public String toArchiveFormat() {
        String result = "";
        result += super.toArchiveFormat() + "," + this.getNumPassengers();
        return result;
    }

    public String toDisplayFormat() {
        String result = "";
        result += super.toDisplayFormat() + "\tPassengers: " + this.getNumPassengers() + "\n";
        result += "\tTotal Weight: " + Common.format(this.calculateWeight());
        return result;
    }

    @Override
    public boolean checkTime() {
        return true;
    }

    @Override
    public boolean checkPassengers() {
        boolean isValid = true;
        if (this.getNumPassengers() < Common.MINIMUM_PASSENGERS) {
            isValid = false;
        }

        return isValid;
    }

    @Override
    public boolean checkWeight() {
        boolean isValid = false;
        if (this.calculateWeight() < Common.MAXIMUM_WEIGHT) {
            isValid = true;
        }
        return isValid;
    }

} // end class PassengerFlight
