package A4_Flights;

/**
 * Cargo inherits from Flight Cargo flights have crew, cargo, but no passengers
 */
// TODO-A2 - Complete this class, using javadocs as a reference
public class CargoFlight extends Flight {

    private int cargoWeight;

    public CargoFlight(String iFlightNumber, String iDayOfWeek, int iDepartureTime, Location iLocation, int iCrewNumber, int iCargoWeight) {
        super(iFlightNumber, iDayOfWeek, iDepartureTime, iLocation, iCrewNumber);
        this.cargoWeight = iCargoWeight;
    }

    public int getCargoWeight() {
        return this.cargoWeight;
    }

    public int calculateWeight() {
        int crewWeight = super.getNumCrew() * Common.AVERAGE_PERSON_WEIGHT;
        int cargoWeigth = this.getCargoWeight();
        return crewWeight + cargoWeigth;
    }

    @Override
    public String getFlightType() {
        return Common.CARGO;
    }

    public String toArchiveFormat() {
        String result = "";
        result += super.toArchiveFormat() + "," + this.getCargoWeight();
        return result;
    }

    public String toDisplayFormat() {
        String result = "";
        result += super.toDisplayFormat() + "\t Total Weight: " + Common.format(this.getCargoWeight());
        return result;
    }

    @Override
    public boolean checkTime() {
        return true;
    }

    @Override
    public boolean checkPassengers() {
        return true;
    }

    @Override
    public boolean checkWeight() {
        boolean isValid = false;
        if (this.calculateWeight() < Common.MAXIMUM_WEIGHT) {
            isValid = true;
        }
        return isValid;
    }

} // end class CargoFlight
