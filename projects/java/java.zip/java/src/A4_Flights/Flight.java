package A4_Flights;

/**
 * Flight - a nonstop flight departing from the home airport
 * Flight is the parent class for Training, Cargo, and Passenger Flights
 */
public abstract class Flight implements PolicyRules{

    // TODO-A1 - Complete this class, using javadocs as a reference
    private String dayOfWeek;
    private int departureTime;
    private Location destination;
    private String flightNumber;
    private int numCrew;
    
    
    public Flight(String iflightNumber,String idayOfWeek, int idepartureTime, Location idestination, int inumCrew){
        this.flightNumber= iflightNumber;
        this.dayOfWeek=idayOfWeek;
        this.departureTime= idepartureTime;
        this.destination= idestination;
        this.numCrew= inumCrew;
    }
            
    public static Flight parseCSV(String line, Location.LocationFinder finder){
        try {
            String[]parts= line.split(",");
            String flightNumber= parts[1];
            String dayOfWeek = String.valueOf(parts[2]);          
            int departureTime= Integer.parseInt(parts[3]);
            Location loc= finder.findLocation(parts[4]);
            int crewNum= Integer.parseInt(parts[5]);
            
            if(parts[0].equals("Passenger"))
                return new PassengerFlight(flightNumber, dayOfWeek, departureTime, loc, crewNum,  Integer.parseInt(parts[6]));
            else if(parts[0].equals("Cargo"))
                return new CargoFlight(flightNumber, dayOfWeek, departureTime, loc, crewNum,Integer.parseInt(parts[6]));
            else if(parts[0].equals("Training"))
                return new TrainingFlight(flightNumber,dayOfWeek,departureTime,loc,crewNum);
            else
                return null;
            
        } catch (Exception ex) {
            System.out.println("Flight parse error, msg= "+ ex.getMessage());
        }
        return null;
    }
    
    public String getDayOfWeek(){
        return this.dayOfWeek;
    }
    
    public int getDepartureTime(){
        return this.departureTime;
    }
    
    
    public Location getDestination(){
        return this.destination;
    }
    
    public String getFlightNumber(){
        return this.flightNumber;
    }
    
    public int getNumCrew(){
        return this.numCrew;
    }
    
    public abstract String getFlightType();
    
        
    public int calculateWeight() { //CHECK PASSENGER AND CARGO DEPENDING ON FLIGHT TYPE
        int crewWeight= this.numCrew * Common.AVERAGE_PERSON_WEIGHT;
        return crewWeight;
    }
    
    
    public String toDisplayFormat() {    
        String result= this.getFlightType()+" Flight = "+ this.getFlightNumber()+", Day = " + this.getDayOfWeek()+", Time = "+ this.getDepartureTime()+"\n";
        result+= "\tDestination: "+ this.getDestination().getLocationCode()+" ("+this.getDestination().getCity()+" , "+ this.getDestination().getCountry()+"), region "+this.destination.getRegion()+"\n";
        result+="\tNumber of Crew: "+ this.getNumCrew()+"\n";

        return result;
    }
    

    public String toArchiveFormat() {
        String result="";
        result+= this.getFlightType()+","+ this.getFlightNumber()+","+ this.getDayOfWeek() + "," +this.getDepartureTime()+","+ this.destination.getLocationCode() +","+ this.getNumCrew();
        return result;
    }

     public boolean checkCrew(){
        boolean isValid=true;
        
        if(this.getNumCrew()<Common.MINIMUM_CREW)
            isValid=false;
        return isValid;
    }
} // end class Flight
