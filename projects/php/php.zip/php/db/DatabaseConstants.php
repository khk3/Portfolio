<?php
class DatabaseConstants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=localhost;dbname=laptopsdb";
    public static $MYSQL_USERNAME = "kkwon";
    public static $MYSQL_PASSWORD = "1234";
}
