<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
</head>

<body>
    <h1>UPDATE ITEM</h1>
    <?php
    require_once __DIR__ . '/db/ConnectionManager.php';
    require_once __DIR__ . '/db/DatabaseConstants.php';

    $stmt = null;
    try {
        $laptopID = $_GET['laptopID'];
        $brand = $_GET['brand'];
        $model = $_GET['model'];
        $storage = $_GET['storage'];
        $ram = $_GET['ram'];
        $graphic = $_GET['graphic'];
        $price = $_GET['price'];

        $cm = new ConnectionManager(
            DatabaseConstants::$MYSQL_CONNECTION_STRING,
            DatabaseConstants::$MYSQL_USERNAME,
            DatabaseConstants::$MYSQL_PASSWORD
        );
        $conn = $cm->getConnection();

        $stmt = $conn->prepare("update laptops set brand=(:brand), model=(:model), storage=(:storage), ram=(:ram), graphic=(:graphic), price=(:price) where ID= (:laptopID)");
        $stmt->bindParam(":laptopID", $laptopID);
        $stmt->bindParam(":brand", $brand);
        $stmt->bindParam(":model", $model);
        $stmt->bindParam(":storage", $storage);
        $stmt->bindParam(":ram", $ram);
        $stmt->bindParam("graphic", $graphic);
        $stmt->bindParam("price", $price);

        $ok = $stmt->execute(); // true doesn't necessarily mean that anything changed - must check rowCount
        $changedRows = $stmt->rowCount();
        $ok = $ok && ($changedRows === 1);
        if ($ok) {
            header("location: showItems.php");
        } else {
            header("Location: errorPage.php?err='could not add laptop" . $laptopID . "'"); // todo: store in session instead
        }
    } catch (PDOException $e) {
        header("Location: errorPage.php?err='" . $e->getMessage() . "'"); // todo: store in session instead
    } finally {
        if (!is_null($stmt)) {
            $stmt->closeCursor();
        }
    }
    ?>
</body>

</html>