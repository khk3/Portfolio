<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Ben's Laptops House </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            padding: 40px;
            background-color: #ffffe6;
        }

        .btnAdd {
            text-align: center;
            margin: 40px;
        }

        .title {
            text-align: center;
            margin: 20px;
        }

        table,
        th,
        td {
            border-collapse: collapse;
            border: 3px solid gray;
        }

        table {
            margin: auto;
        }

        th,
        td {
            padding: 8px;
        }
    </style>

</head>

<body>
    <div>
        <p class="fs-1 title">BEN'S LAPTOPS</p>
        <form action="addItem.php" class='btnAdd'>
            <button type="submit" class="btn btn-primary" name="add">Add Laptop</button>
        </form>
        <table>
            <tr>
                <th>ID</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Storage</th>
                <th>RAM</th>
                <th>Graphic</th>
                <th>Price</th>
                <th></th> <!--For edit column-->
            </tr>
            <?php
            require_once __DIR__ . '/db/ConnectionManager.php';
            require_once __DIR__ . '/db/DatabaseConstants.php';

            $stmt = null;
            try {
                $cm = new ConnectionManager(
                    DatabaseConstants::$MYSQL_CONNECTION_STRING,
                    DatabaseConstants::$MYSQL_USERNAME,
                    DatabaseConstants::$MYSQL_PASSWORD
                );
                $conn = $cm->getConnection();
                $stmt = $conn->prepare("SELECT * from laptops");
                $stmt->execute();
                $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($dbresults as $r) {
                    $laptopID = $r['ID'];
                    $brand = $r['Brand'];
                    $model = $r['Model'];
                    $storage = $r['Storage'];
                    $ram = $r['RAM'];
                    $graphic = $r['Graphic'];
                    $price = $r['Price'];
            ?>
                    <tr>
                        <td>
                            <?php echo $laptopID; ?>
                        </td>
                        <td>
                            <?php echo $brand; ?>
                        </td>
                        <td>
                            <?php echo $model; ?>
                        </td>
                        <td>
                            <?php echo $storage; ?>
                        </td>
                        <td>
                            <?php echo $ram; ?>
                        </td>
                        <td>
                            <?php echo $graphic; ?>
                        </td>
                        <td>
                            <?php echo $price; ?>
                        </td>
                        <td>
                            <form>
                                <input type='hidden' name='laptopID' value='<?php echo $laptopID; ?>'>
                                <input type='hidden' name='brand' value='<?php echo $brand; ?>'>
                                <input type='hidden' name='model' value='<?php echo $model; ?>'>
                                <input type='hidden' name='storage' value='<?php echo $storage; ?>'>
                                <input type='hidden' name='ram' value='<?php echo $ram; ?>'>
                                <input type='hidden' name='graphic' value='<?php echo $graphic; ?>'>
                                <input type='hidden' name='price' value='<?php echo $price; ?>'>
                                <button type='submit' name='update' formaction='updateItem.php'>
                                    <img src='icons/pencil.svg' alt='pencil icon'>
                                </button>
                                <button type='submit' class='' formaction='delete.php'>
                                    <img src='icons/trash3.svg' alt='trash icon'>
                                </button>
                            </form>
                        </td>
                    </tr>
            <?php
                } // end loop 
            } catch (PDOException $e) {
                header("Location: errorPage.php?err='" . $e->getMessage() . "'");
            } finally {
                if (!is_null($stmt)) {
                    $stmt->closeCursor();
                }
            }
            ?>
        </table>

    </div> <!-- END OF CONTENT -->


</body>

</html>