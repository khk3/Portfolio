<?php
require_once __DIR__ . '/db/ConnectionManager.php';
require_once __DIR__ . '/db/DatabaseConstants.php';

$laptopID = $_GET['laptopID'];

$stmt = null;
try {
    $cm = new ConnectionManager(
        DatabaseConstants::$MYSQL_CONNECTION_STRING,
        DatabaseConstants::$MYSQL_USERNAME,
        DatabaseConstants::$MYSQL_PASSWORD
    );
    $conn = $cm->getConnection();
    //$stmt = $conn->prepare("delete from MENUITEM where itemID = " . $itemID);
    $stmt = $conn->prepare("delete from laptops where ID = :laptop");

    $stmt->bindParam(":laptop", $laptopID);

    $ok = $stmt->execute(); // true doesn't necessarily mean that anything changed - must check rowCount
    $changedRows = $stmt->rowCount();
    $ok = $ok && ($changedRows === 1);
    if ($ok) {
        header("Location: showItems.php");
    } else {
        // item does not exist
        header("Location: errorPage.php?err='Could not delete item " . $laptopID . "'."); // todo: store in session instead
    }
} catch (PDOException $e) {
    // shouldn't happen unless there's an error in the SQL 
    header("Location: errorPage.php?err='" . $e->getMessage() . "'"); // todo: store in session instead
} finally {
    if (!is_null($stmt)) {
        $stmt->closeCursor();
    }
}
