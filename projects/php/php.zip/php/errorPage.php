<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <title>Database Demo 1</title>
    <style>
        .container{
        margin:auto;
        text-align: center;
        }
    </style>
</head>

<body>
    <?php
    include "utils/ChromePhp.php";

    ?>

    <div id="content" class="container">
        <h1>Error Page</h1>
        <p><?php echo $_GET['err']; ?></p>
        <form action="showItems.php">
            <button type="submit">Home</button>
        </form>
    </div>
</body>

</html>