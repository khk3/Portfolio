<?php
require_once __DIR__ . '/db/ConnectionManager.php';
require_once __DIR__ . '/db/DatabaseConstants.php';

$stmt = null;
try {
    $laptopID = $_GET['laptopID'];
    $brand = $_GET['brand'];
    $model = $_GET['model'];
    $storage = $_GET['storage'];
    $ram = $_GET['ram'];
   
    $graphic = $_GET['graphic'];
    $price= $_GET['price'];
    
    $cm = new ConnectionManager(
        DatabaseConstants::$MYSQL_CONNECTION_STRING,
        DatabaseConstants::$MYSQL_USERNAME,
        DatabaseConstants::$MYSQL_PASSWORD
    );
    $conn = $cm->getConnection();

    $stmt = $conn->prepare("insert into laptops values (:laptopID, :brand, :model, :storage, :ram, :graphic, :price)");
    $stmt->bindParam(":laptopID", $laptopID);
    $stmt->bindParam(":brand", $brand);
    $stmt->bindParam(":model", $model);
    $stmt->bindParam(":storage", $storage);
    $stmt->bindParam(":ram", $ram);
    $stmt->bindParam(":graphic", $graphic);
    $stmt->bindParam(":price", $price);
    
    if(empty($laptopID)||empty($brand)||empty($model)||empty($storage)||empty($ram)||empty($graphic)||empty($price)) 
    {
        header("location:errorPage.php?err='No empty fields allowed'");
        
    } else if (!is_numeric($storage) || !is_numeric($ram) || !is_numeric($price)) 
    {
        header("location:errorPage.php?err='Storage, RAM and Price must be numbers only.'");
    
    }
    else {
        $ok = $stmt->execute(); // true doesn't necessarily mean that anything changed - must check rowCount
        $changedRows = $stmt->rowCount();
        $ok = $ok && ($changedRows === 1);
        if ($ok) {
            header("location: showItems.php");
        } else {
            header("Location: errorPage.php?err='could not add laptop" . $laptopID . "'"); // todo: store in session instead  
        }
    }
 
} catch (PDOException $e) {
    $errorMessage = $e->getMessage();

    if (strpos($errorMessage, "for key 'laptops.PRIMARY'") ==true) {
        // Display a custom error message for duplicate entry
        header("Location: errorPage.php?err=The Laptop ID must be unique. The ID '$laptopID' is already set.");
    } else {
        // Display a generic error message for other database errors
        header("Location: errorPage.php?err=Database error: $errorMessage");
    }
} finally {
    if (!is_null($stmt)) {
        $stmt->closeCursor();
    }
}
