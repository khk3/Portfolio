<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update ITEM</title>
    <style>
        body {
            padding: 40px;
            background-color: #ffffe6;
        }

        .btnAdd {
            text-align: center;
            margin: 40px;
        }

        .divAdd {
            width: 800px;
            height: 600px;

        }

        label {
            display: inline-block;
            width: 130px;
            padding: 10px;
            font-size: 1.5em;
            text-align: end;
        }

        button {
            width: 80px;
            padding: 10px;
            margin: 10px;
        }

        input[type="text"] {
            padding: 10px;
        }

        form {
            text-align: center;
            margin: auto;
        }
    </style>
</head>

<body>
    <?php
    include "utils/ChromePhp.php";
    ChromePhp::log($_GET["laptopID"]);
    ?>

    <div>
        <h1 class='btnAdd'>Update Laptop</h1>
        <form action="" class='divAdd'>
            <div class="addItem">
                <label for="">LaptopID: </label>
                <input type="text" name='laptopID' value=<?php echo $_GET["laptopID"] ?> readonly="true"><br>
            </div>
            <div class="addItem">
                <label for="">Brand: </label>
                <input type="text" name='brand' value=<?php echo $_GET["brand"] ?>><br>
            </div>
            <div class="addItem">
                <label for="">Model: </label>
                <input type="text" name='model' value=<?php echo $_GET["model"] ?>><br>
            </div>
            <div class="addItem">
                <label for="">Storage</label>
                <input type="text" name='storage' value=<?php echo $_GET["storage"] ?>><br>
            </div>
            <div class="addItem">
                <label for="">RAM</label>

                <input type="text" name='ram' value=<?php echo $_GET["ram"] ?>><br>
            </div>
            <div class="addItem">
                <label for="">Graphic</label>
                <input type="text" name='graphic' value=<?php echo $_GET["graphic"] ?>><br>
            </div>
            <div class="addItem">
                <label for="">Price</label>
                <input type="text" name='price' value=<?php echo $_GET["price"] ?>><br>
            </div>
            <div class="addItem">
                <button type='submit' formaction="updateItem2.php">Update</button>
                <button type='submit' formaction="showItems.php">Cancel</button>
            </div>
        </form>

    </div>
</body>

</html>