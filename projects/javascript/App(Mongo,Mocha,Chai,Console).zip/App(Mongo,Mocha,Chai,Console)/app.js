/**
 * Assignment 3 - Main program
 */
const readline = require("node:readline/promises");
const { MenuItem } = require("./entity/MenuItem");
const api = require("./api/RestaurantService");
const db= require("./db/DatabaseBuilder");

const input = process.stdin; // stdin is the keyboard
const output = process.stdout; // stdout is the monitor (screen)
const reader = readline.createInterface({ input, output });

main();

async function main() {
    let keepGoing = true;
    while (keepGoing) {
        let command = (await reader.question("Enter a command (or 'quit'). Type \'help\' to see the commands available. "))
            .trim()
            .toLowerCase();
        switch (command) {
            case "list":
                await doList();
                break;
            case "add":
                await doAdd();
                break;
            case "delete":
                await doDelete();
                break;
            case "update":
                await doUpdate();
                break;
            case "help":
                showCommands();
                break;
            case "quit":
                keepGoing = false;
                break;
            default:
                console.log(`  '${command}' is not a recognized command.`);
                break;
        }
    }
    reader.close();
}

async function doList() {
    //db.rebuild();
    let resp = await api.processRequest("LIST", null);
    console.log("  Status: " + resp.statusCode);
    if (resp.err) {
        console.log("  Response: " + resp.err);
    } else {
        let items = resp.data;
        console.log("  Response:");
        items.forEach((item) => console.log(item.formatItem()));
    }
}

async function doAdd() {
    let obj = await getObjectToAddOrUpdate();
    let resp = await api.processRequest("ADD", obj);
    console.log("  Status: " + resp.statusCode);
    if (resp.err) {
        console.log("  Response: " + resp.err);
    } else {
        let ok = resp.data;
        console.log(
            "  Response: Add operation " + (ok ? "succeeded" : "failed")
        );
    }
}

async function doDelete() {
    let obj = await getObjectToDelete();
    let resp = await api.processRequest("DELETE", obj);
    console.log("  Status: " + resp.statusCode);
    if (resp.err) {
        console.log("  Response: " + resp.err);
    } else {
        let ok = resp.data;
        console.log(
            "  Response: Delete operation " + (ok ? "succeeded" : "failed")
        );
    }
}

async function doUpdate() {
    let obj = await getObjectToAddOrUpdate();
    let resp = await api.processRequest("UPDATE", obj);
    console.log("  Status: " + resp.statusCode);
    if (resp.err) {
        console.log("  Response: " + resp.err);
    } else {
        let ok = resp.data;
        console.log("  Data:");
        console.log(
            "  Response: Update operation " + (ok ? "succeeded" : "failed")
        );
    }
}

async function getObjectToAddOrUpdate() {
    let id = Number(await reader.question("Enter the ID: "));
    let cat = await reader.question("Enter the category: ");
    let desc = await reader.question("Enter the description: ");
    let price = Number(await reader.question("Enter the price: "));
    let vegStr = await reader.question("Is the item vegetarian (Y/N): ");
    let veg;
    if (vegStr==="Y"|| vegStr==="y")
        veg=true;
    else
        veg=false;
    //let veg = vegStr === "Y" || vegStr === "y";
    return new MenuItem(id, cat, desc, price, veg);
}

async function getObjectToDelete() {
    let id = Number(await reader.question("Enter the ID: "));
    let obj = new MenuItem(id,"","",0,true); // dummy object
    return obj;
}

function showCommands() { 
    console.log("\'List\': will show the list of the menu items in database. \n"+
        "\'Add\': will add a new item to the database if not already exists. \n"+
        "\'Delete\': will delete the item if exists in the database. \n"+
        "\'Update\': will update the item if exists in the database."
    );
}