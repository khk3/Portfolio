1-This program use the commandline build a list through a database (MongoDB). Depending on the command the api(.api/RestaurantService.js) will perform the CRUD operation.
2-Also,you can perform a test using Mocha Chai- You can run using the comnand: 'npm test'(./test.js)

To read the database and see the list of items( Restaurant Items in this case) please run on the console: node app
You will see the message : 'Enter a command (or 'quit'). Type 'help' to see the commands available.'

