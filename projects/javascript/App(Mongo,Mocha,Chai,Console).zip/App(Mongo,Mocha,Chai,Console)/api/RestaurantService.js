/**
 * API for Console CRUD application.
 */
const mia = require("../db/MenuItemAccessor");
const { MenuItem } = require("../entity/MenuItem");

/**
 * Handles a request to perform an action on the dataset.
 *
 * @param {string} action - the action to perform: one of LIST, ADD, UPDATE, DELETE
 * @param {MenuItem} content - the object to be added, updated, or deleted; null for LIST requests.
 * @returns {Promise<object>} - resolves to: an object containing three fields: statusCode, err, data.
 *                              As per convention, only one of err or data will be populated.
 */
async function processRequest(action, content) {
    //your code here
    if (!action) {
        resp = createResponseObject(
            405,
            'unknown operation',
            null
        );
        return resp;
    }
    else if(action) {
        switch (action.toUpperCase()) {
            case "LIST":
                resp = doList();
                break;
            case "ADD":
                resp = doAdd(content);
                break;
            case "UPDATE":
                resp = doUpdate(content);
                break;
            case "DELETE":
                resp = doDelete(content);
                break;
            default:
                resp = {
                    statusCode: 405,
                    err: 'unknown operation',
                    data: null,
                };
            
        }//end of switch
        return resp;
    }
}
   
async function doList() {
//console.log("todoList");
    let resp;
    try {
        let items = await mia.getAllItems();
            resp = createResponseObject(200, null, items);
    } catch (err) {
        resp = createResponseObject(
            500,
            "server error - please try again later",
            null
        );
    }
    return resp;
}

async function doAdd(item) {
    try {
        let resp;
        //let ok = await mia.addItem(item);
        if(item instanceof MenuItem) 
        {
           let ok = await mia.addItem(item);
            if (ok) {
                resp = createResponseObject(201, null, true);
                return resp;
            } else {
                resp = createResponseObject(409, 'entity already exists - could not be added', null);
                return resp;
            }
        }
        else{
            resp = createResponseObject(400, 'unrecognized entity', null);
            return resp;
        }
    } catch (error) {
        resp = createResponseObject(
            500,
            "server error - please try again later",
            null);
            return resp;
    }
}

async function doDelete(item) {
    try {
        if(item instanceof MenuItem && item!=null){
            let ok = await mia.deleteItem(item);
            let resp;
            if (ok) {
                resp = createResponseObject(200, null, true);
                return resp;
            } else {
                resp = createResponseObject(404, 'entity does not exist - could not delete', null);
                return resp;
            }
        }
        else {
            resp = createResponseObject(400, 'unrecognized entity', null);
            return resp;
        }
    } catch (error) {
        resp = createResponseObject(
            500,
            "server error - please try again later",
            null);
        return resp;
    }

}//end of function doDelete

async function doUpdate(item) {
    try {
        if (item instanceof MenuItem && item != null) {
            let ok = await mia.updateItem(item);
            let resp;
            if (ok) {
                resp = createResponseObject(200, null, true);
                return resp;
            } else {
                resp = createResponseObject(404, 'entity does not exist - could not delete', null);
                return resp;
            }
        }
        else{
            resp = createResponseObject(400, 'unrecognized entity' ,null);
            return resp;
        }
    } catch (error) {
        resp = createResponseObject(
            500,
            "server error - please try again later",
            null);
        return resp;
    }
}//end of function doUpdate


function createResponseObject(statusCode, err, data) {
    return {
        statusCode: statusCode,
        err: err,
        data: data,
    };
}

exports.processRequest = processRequest;
