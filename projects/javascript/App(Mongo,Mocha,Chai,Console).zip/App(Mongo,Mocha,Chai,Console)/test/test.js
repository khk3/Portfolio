// your code here
const assert = require("chai").assert;
const { ConnectionManager } = require("../db/ConnectionManager");
const dbbuilder = require("../db/DatabaseBuilder");
const acc = require("../db/MenuItemAccessor");
const { MenuItem } = require("../entity/MenuItem");
const { Constants } = require("../utils/Constants");
const api = require("../api/RestaurantService");

let testItems;

describe("RestaurantService Tests", function () {
    // Before running any of the tests, ensure that the database
    // has been restored to its original state.

    before("Setup", async function () {

        testItems = await defineTestItems();

        await ConnectionManager.getConnection(); // open a connection to be shared

        await dbbuilder.rebuild();

        console.log("    <<setup: Database restored to original state.>>");
    });//enf of before

    after("Teardown", async function () {
        await ConnectionManager.closeConnection(); // close the shared connection
    });//end of after

    describe("Good Requests(200 series)", async function () {
        it("LIST returns status 200, null error, and correct list of items", async function () {
            let expectedStatus = 200,
                expectedErr = null;

            let resp = await api.processRequest("LIST");
            //console.log("list statuscode"+resp.statusCode);
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            let items = resp.data;
            assert.equal(items.length, Constants.NUM_ITEMS);
            assert.isTrue(
                items[0] instanceof MenuItem && items[38] instanceof MenuItem,
                "items should be instances of MenuItem");
        });//end of it: 1

        it("ADD adds a new item, returns status 201, null error, and data true, if item does not already exist", async function () {

            let exist = await acc.itemExists(testItems.itemToAdd);
            //console.log("exist: "+exist);
            assert.equal(exist, false);
            //let add= await acc.addItem(testItems.itemToAdd);
            let resp = await api.processRequest("ADD", testItems.itemToAdd);

            let expectedStatus = 201,
                expectedErr = null;
            expectedBool = true;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedBool);
        });//end of it: 2


        it("DELETE deletes an item, return status 200, null error, and data true, if item exists.", async function () {
            let exist = await acc.itemExists(testItems.itemToDelete);
            assert.equal(exist, true);
            let resp = await api.processRequest("DELETE", testItems.itemToDelete);
            let expectedStatus = 200,
                expectedErr = null;
            expectedBool = true;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedBool);
        });//end of it: 3


        it("UPDATE updates an item, return status 200, null error, and data true, if item exists.", async function () {
            let exist = await acc.itemExists(testItems.itemToUpdate);
            assert.equal(exist, true);
            let resp = await api.processRequest("UPDATE", testItems.itemToUpdate);
            let expectedStatus = 200,
                expectedErr = null;
            expectedBool = true;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedBool);
        });//end of it: 4
    });//end of describe Good Requests


    describe("Bad Requests (400 series)", async function () {
        describe("Invalid Commands - expect: status 405, error message, and null data", async function () {
            it("Command is empty: API returns expected response", async function () {
                let command = "";
                let resp = await api.processRequest(command, testItems.itemToUpdate);
                let expectedStatus = 405,
                    expectedErr = 'unknown operation';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 5

            it("Command is null: API returns expected response", async function () {
                let command = null;
                let resp = await api.processRequest(command, testItems.itemToUpdate);
                let expectedStatus = 405,
                    expectedErr = 'unknown operation';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 6

            it("Command is 'foo': API returns expected response", async function () {
                let command = "foo";
                let resp = await api.processRequest(command, testItems.itemToUpdate);
                let expectedStatus = 405,
                    expectedErr = 'unknown operation';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 7

            it("Command is 'addd': API returns expected response", async function () {
                let command = "addd";
                let resp = await api.processRequest(command, testItems.itemToUpdate);
                let expectedStatus = 405,
                    expectedErr = 'unknown operation';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 8

            it("Command is 'ad': API returns expected response", async function () {
                let command = "ad";
                let resp = await api.processRequest(command, testItems.itemToUpdate);
                let expectedStatus = 405,
                    expectedErr = 'unknown operation';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 9
        });// end of invalid commands


        describe("Content is not an Object = expect: status 400, error message, and null data", async function () {
            it("Content is omitted: DELETE does not change database, and returns expected response", async function () {
                let command = "DELETE";
                let content;
                let resp = await api.processRequest(command);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                //console.log("statusCode:"+ resp.statusCode);
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 10

            it("Content is null: DELETE does not change database, and returns expected response", async function () {
                let command = "DELETE";
                let content = null;
                let resp = await api.processRequest(command, null);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                //console.log("statusCode:"+ resp.statusCode);
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 11

            it("Content is a string: DELETE does not change database, and returns expected response", async function () {
                let command = "DELETE";
                let content = 'NBCC';
                let resp = await api.processRequest(command, content);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                //console.log("statusCode:"+ resp.statusCode);
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 12

            it("Content is a valid ID (number): DELETE does not change database, and returns expected response", async function () {
                let command = "DELETE";
                let content = 101;
                let resp = await api.processRequest(command, content);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                //console.log("statusCode:"+ resp.statusCode);
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 13
        });//end of describe content is not an Object

        describe("Content is an Object but not a MenuItem - expect: status 400, error message, and null data", async function () {
            it("ADD returns expected response", async function () {
                let command = "ADD";
                let obj = { id: 999, category: "DES", description: "apple crisp", price: 12, vegetarian: true };
                let resp = await api.processRequest(command, obj);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 14

            it("DELETE returns expected response", async function () {
                let command = "DELETE";
                let obj = { id: 201, category: "ENT", description: "black cop", price: 21, vegetarian: false };
                let resp = await api.processRequest(command, obj);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 15

            it("UPDATE returns expected response", async function () {
                let command = "UPDATE";
                let obj = { id: 301, category: "DES", description: "wrong", price: -1, vegetarian: false };
                let resp = await api.processRequest(command, obj);
                let expectedStatus = 400,
                    expectedErr = 'unrecognized entity';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 16
        });//end of describe Content is an Object but not a MenuItem

        describe("Content is a MenuItem, but the operation cannot be performed", async function () {
            it("ADD does not change database, returns status 409, error message, and null data if item already exists", async function () {
                let command = "ADD";
                let content = testItems.goodItem;
                let resp = await api.processRequest(command, content);
                let expectedStatus = 409;
                expectedErr = 'entity already exists - could not be added';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 17

            it("DELETE does not change database, returns status 409, error message, and null data if item does not exists", async function () {
                let command = "DELETE";
                let content = testItems.badItem;
                let resp = await api.processRequest(command, content);
                let expectedStatus = 404;
                expectedErr = 'entity does not exist - could not delete';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });
            it("UPDATE does not change database, returns status 409, error message, and null data if item does not exists", async function () {
                let command = "UPDATE";
                let content = testItems.badItem;
                let resp = await api.processRequest(command, content);
                let expectedStatus = 404;
                expectedErr = 'entity does not exist - could not delete';
                expectedData = null;
                assert.equal(resp.statusCode, expectedStatus);
                assert.equal(resp.err, expectedErr);
                assert.equal(resp.data, expectedData);
            });//end of it: 19

        });// end of describe operation cannot be performed
    });//end of describe bad requests

    describe("Server Errors (500 series) - expect: status 500, error message, and null data", function () {
        before("Setup - corrupt connection URI", async function () {
            Constants.DB_URI = "mongodb://127.0.0.1:99999"; // change port to a invalid value
            console.log("      <<SETUP: Connection URI corrupted.>>");
        });
        after("Teardown = restore valid connection URI", async function () {
            Constants.DB_URI = "mongodb://127.0.0.1:27017"; // correct the port 
            console.log("      <<TEARDOWN: Connection URI repaired)");
        });

        it("LIST returns expected response, if there is a server-side error", async function () {
            let command = "LIST";
            let resp = await api.processRequest(command);
            let expectedStatus = 500;
            expectedErr = "server error - please try again later";
            expectedData = null;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedData);
        });//end of it: 20

        it("ADD returns expected response, if there is a server-side error", async function () {
            let command = "ADD";
            let content = testItems.itemToAdd;
            let resp = await api.processRequest(command, content);
            let expectedStatus = 500;
            expectedErr = "server error - please try again later";
            expectedData = null;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedData);
        });//end of it: 21

        it("DELETE returns expected response, if there is a server-side error", async function () {
            let command = "DELETE";
            let content = testItems.itemToDelete;
            let resp = await api.processRequest(command, content);
            let expectedStatus = 500;
            expectedErr = "server error - please try again later";
            expectedData = null;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedData);
        });//end of it: 22

        it("UPDATE returns expected response, if there is a server-side error", async function () {
            let command = "UPDATE";
            let content = testItems.itemToUpdate;
            let resp = await api.processRequest(command, content);
            let expectedStatus = 500;
            expectedErr = "server error - please try again later";
            expectedData = null;
            assert.equal(resp.statusCode, expectedStatus);
            assert.equal(resp.err, expectedErr);
            assert.equal(resp.data, expectedData);
        });//end of it: 23
    });//end describe Server Errors
});//end of TESTS


///*** HELPERS ***///
function defineTestItems() {
    return {
        goodItem: new MenuItem(107, "", "", 0, false),
        badItem: new MenuItem(777, "", "", 0, false),
        itemToAdd: new MenuItem(888, "ENT", "poutine", 11, false),
        itemToDelete: new MenuItem(202, "", "", 30, false),
        itemToUpdate: new MenuItem(303, "ENT", "after update", 11, false),
        wrongTypeItem: {
            id: 107,
            category: "",
            description: "",
            price: 0,
            vegetarian: false,
        },
    };
}
