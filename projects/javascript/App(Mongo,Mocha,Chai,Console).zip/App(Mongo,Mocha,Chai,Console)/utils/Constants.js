/**
 * Some useful constants
 *
 * @module Constants
 */

// your code here
/** The connection URI for MongoDB. */
const DB_URI = "mongodb://127.0.0.1:27017";

/** The database name. */
const DB_NAME = "restaurantdb";

/** The collection name. */
const DB_COLLECTION = "menuitems";

/** The number of records in the collection. */
const NUM_ITEMS = 39;

exports.Constants = {
    DB_URI: DB_URI,
    DB_NAME: DB_NAME,
    DB_COLLECTION: DB_COLLECTION,
    NUM_ITEMS: NUM_ITEMS,
};
