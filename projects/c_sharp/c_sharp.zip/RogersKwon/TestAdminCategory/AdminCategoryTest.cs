using Microsoft.VisualStudio.TestTools.UnitTesting;
using RogersKwon; //saves time for referring to classes in that namespace

//Written by Kang
//Unit Testing
//Test the Validation to set the Category of User Admin.
namespace TestAdminCategory
{
    [TestClass]
    public class AdminCategoryTest
    {
        [TestMethod]
        public void TestInvalidAge() 
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Junior";

            //act set yearAtCompany = -1
            admin.YearsAtCompany = -1;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

        [TestMethod]
        public void TestLevelJunior()
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Junior";

            //act set yearAtCompany 
            admin.YearsAtCompany = 3;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

        [TestMethod]
        public void TestLevelIntermediate()
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Intermediate";

            //act set yearAtCompany  = 8
            admin.YearsAtCompany = 8;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

        [TestMethod]
        public void TestLevelSenior()
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Senior";

            //act set yearAtCompany  = 8
            admin.YearsAtCompany = 15;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

        [TestMethod]
        public void TestLevelRetired()
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Retired";

            //act set yearAtCompany  = 8
            admin.YearsAtCompany = 38;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

        [TestMethod]
        public void TestUnknown()
        {
            //arrange
            Admin admin = new Admin();
            string categoryExpected = "Unknown";

            //act set yearAtCompany  = 8
            admin.YearsAtCompany = 55;

            //assert
            Assert.AreEqual(categoryExpected, admin.Category, "Wrong Category");
        }

    }
}