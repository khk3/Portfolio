﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RogersKwon
{
    public class Users
    {
        //All property declartion for USers
        public int Id;
        public string LastName, FirstName, Password, Login;
        public bool Access;

        //Static Variable, NextID, Set from SetID()
        private static int nextID = 100;

        //Constant Declaration for INCREMENT
        private const int INCREMENT = 1;

        //Default Constructor, Does nothing
        public Users() { }
        //Custom Constructor, Sets all User properties gained from file, Creates ID calling SetID()
        public Users(string lastName, string firstName, string login, string password, bool access)
        {
            SetID();
            LastName = lastName;
            FirstName = firstName;
            Password = password;
            Login = login;
            Access = access;
        }

        //Written by Kang
        //Method: SetID()
        //Sent: Nothing
        //Returned: Nothing
        //Description: Sets a users ID to nextID and uses increment to Set nextID to next value
        private void SetID()
        {
            Id = nextID;
            nextID += INCREMENT;
        }

    }//end of class Users

    //Written by Noah and Kang
    //Derived Class from Users: 'Customer' - Sealed
    //Description: customer class, adds loyaltyMember property
    public sealed class Customer : Users
    {
        //Customer Property
        public bool LoyaltyMember;

        //Default Constructor: does nothing
        public Customer() { }

        //Custom Constructor: calls base custom to set properties, also sets loyaltyMember
        public Customer(string lastName, string firstName, string login, string password, bool access, bool loyalty) : base(lastName, firstName, login, password, access)
        {
            LoyaltyMember = loyalty;
        }
    }

    //Written by Noah and Kang
    //Derived Class from Users: 'Admin' - Sealed
    //Description: Admin class, adds hiredDate,
    public sealed class Admin : Users
    {
        public string HiredDate;
        public string Category; //Unit testing property
        private int yearsAtCompany;
        public int YearsAtCompany
        {
            get { return yearsAtCompany; }

            set { yearsAtCompany = (value < 0) ? 0 : value;
                SetCategory(); //Unit testing call        
            }
        }

        //Default Constructor: does nothing
        public Admin() { }

        //Custom Constructor: calls base custom to set properties, also sets hired Date and Years
        public Admin(string lastName, string firstName, string login, string password, bool access, string hiredDate, int yearsAtCompany) : base(lastName, firstName, login, password, access)
        {
            HiredDate = hiredDate;
            YearsAtCompany = yearsAtCompany;
        }

        //Written by Kang
        //Unit testing: SetCategory
        private void SetCategory()
        {
            if (YearsAtCompany >= 12 && YearsAtCompany<=35)
            {
                Category = "Senior";
            }
            else if (YearsAtCompany >= 7 && YearsAtCompany <= 11)
            {
                Category = "Intermediate";
            }
            else if(YearsAtCompany >=0 && YearsAtCompany < 7)
            {
                Category = "Junior";
            }
            else if(YearsAtCompany > 35 && YearsAtCompany <50)
            {
                Category = "Retired";
            }
            else
                Category = "Unknown";
                
        }

    }//End of admin 

 
}
