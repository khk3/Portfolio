﻿namespace RogersKwon
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcAdmin = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lstDesktops = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lstLaptops = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtBrand = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtProcessor = new System.Windows.Forms.TextBox();
            this.txtRam = new System.Windows.Forms.TextBox();
            this.txtProp1 = new System.Windows.Forms.TextBox();
            this.txtProp2 = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblProp1 = new System.Windows.Forms.Label();
            this.lblProp2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lblAdminName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblHiringDate = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblYearsAtCompany = new System.Windows.Forms.Label();
            this.txtInStock = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tbcAdmin.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // tbcAdmin
            // 
            this.tbcAdmin.Controls.Add(this.tabPage1);
            this.tbcAdmin.Controls.Add(this.tabPage2);
            this.tbcAdmin.Location = new System.Drawing.Point(14, 108);
            this.tbcAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.tbcAdmin.Name = "tbcAdmin";
            this.tbcAdmin.SelectedIndex = 0;
            this.tbcAdmin.Size = new System.Drawing.Size(550, 424);
            this.tbcAdmin.TabIndex = 0;
            this.tbcAdmin.SelectedIndexChanged += new System.EventHandler(this.tbcAdmin_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.lstDesktops);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(542, 391);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Desktops";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(96, 40);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 20);
            this.label15.TabIndex = 25;
            this.label15.Text = "Stock";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(443, 40);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 20);
            this.label16.TabIndex = 24;
            this.label16.Text = "Price";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(337, 40);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 20);
            this.label13.TabIndex = 21;
            this.label13.Text = "RAM";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(249, 40);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 20);
            this.label11.TabIndex = 19;
            this.label11.Text = "Brand";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(170, 40);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 20);
            this.label10.TabIndex = 18;
            this.label10.Text = "Code";
            // 
            // lstDesktops
            // 
            this.lstDesktops.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDesktops.FormattingEnabled = true;
            this.lstDesktops.ItemHeight = 18;
            this.lstDesktops.Location = new System.Drawing.Point(7, 70);
            this.lstDesktops.Margin = new System.Windows.Forms.Padding(4);
            this.lstDesktops.Name = "lstDesktops";
            this.lstDesktops.Size = new System.Drawing.Size(515, 328);
            this.lstDesktops.TabIndex = 1;
            this.lstDesktops.SelectedIndexChanged += new System.EventHandler(this.lstDesktops_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.lstLaptops);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(542, 391);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Laptops";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(94, 20);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 20);
            this.label17.TabIndex = 34;
            this.label17.Text = "Stock";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(464, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 33;
            this.label6.Text = "Price";
            // 
            // lstLaptops
            // 
            this.lstLaptops.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstLaptops.FormattingEnabled = true;
            this.lstLaptops.ItemHeight = 18;
            this.lstLaptops.Location = new System.Drawing.Point(7, 47);
            this.lstLaptops.Margin = new System.Windows.Forms.Padding(4);
            this.lstLaptops.Name = "lstLaptops";
            this.lstLaptops.Size = new System.Drawing.Size(515, 310);
            this.lstLaptops.TabIndex = 25;
            this.lstLaptops.SelectedIndexChanged += new System.EventHandler(this.lstLaptops_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(179, 22);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 20);
            this.label21.TabIndex = 27;
            this.label21.Text = "Code";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(253, 22);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 20);
            this.label20.TabIndex = 28;
            this.label20.Text = "Brand";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(341, 20);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 20);
            this.label18.TabIndex = 30;
            this.label18.Text = "RAM";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(622, 115);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Code";
            // 
            // txtCode
            // 
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCode.Location = new System.Drawing.Point(674, 108);
            this.txtCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtCode.Name = "txtCode";
            this.txtCode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCode.Size = new System.Drawing.Size(112, 27);
            this.txtCode.TabIndex = 0;
            this.txtCode.Tag = "Code";
            this.txtCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBrand
            // 
            this.txtBrand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBrand.Location = new System.Drawing.Point(674, 171);
            this.txtBrand.Margin = new System.Windows.Forms.Padding(4);
            this.txtBrand.Name = "txtBrand";
            this.txtBrand.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtBrand.Size = new System.Drawing.Size(112, 27);
            this.txtBrand.TabIndex = 1;
            this.txtBrand.Tag = "Brand";
            this.txtBrand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtModel
            // 
            this.txtModel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtModel.Location = new System.Drawing.Point(674, 235);
            this.txtModel.Margin = new System.Windows.Forms.Padding(4);
            this.txtModel.Name = "txtModel";
            this.txtModel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtModel.Size = new System.Drawing.Size(112, 27);
            this.txtModel.TabIndex = 2;
            this.txtModel.Tag = "Model";
            this.txtModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProcessor
            // 
            this.txtProcessor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProcessor.Location = new System.Drawing.Point(674, 296);
            this.txtProcessor.Margin = new System.Windows.Forms.Padding(4);
            this.txtProcessor.Name = "txtProcessor";
            this.txtProcessor.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtProcessor.Size = new System.Drawing.Size(112, 27);
            this.txtProcessor.TabIndex = 3;
            this.txtProcessor.Tag = "Processor";
            this.txtProcessor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtRam
            // 
            this.txtRam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRam.Location = new System.Drawing.Point(674, 357);
            this.txtRam.Margin = new System.Windows.Forms.Padding(4);
            this.txtRam.Name = "txtRam";
            this.txtRam.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRam.Size = new System.Drawing.Size(112, 27);
            this.txtRam.TabIndex = 4;
            this.txtRam.Tag = "RAM";
            this.txtRam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProp1
            // 
            this.txtProp1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProp1.Location = new System.Drawing.Point(920, 291);
            this.txtProp1.Margin = new System.Windows.Forms.Padding(4);
            this.txtProp1.Name = "txtProp1";
            this.txtProp1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtProp1.Size = new System.Drawing.Size(112, 27);
            this.txtProp1.TabIndex = 7;
            this.txtProp1.Tag = "AllInOne or ScreenSize";
            this.txtProp1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProp2
            // 
            this.txtProp2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProp2.Location = new System.Drawing.Point(920, 227);
            this.txtProp2.Margin = new System.Windows.Forms.Padding(4);
            this.txtProp2.Name = "txtProp2";
            this.txtProp2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtProp2.Size = new System.Drawing.Size(112, 27);
            this.txtProp2.TabIndex = 6;
            this.txtProp2.Tag = "Graphic or Battery";
            this.txtProp2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPrice
            // 
            this.txtPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrice.Location = new System.Drawing.Point(920, 357);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtPrice.Size = new System.Drawing.Size(112, 27);
            this.txtPrice.TabIndex = 8;
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(612, 178);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Brand";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(612, 242);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Model";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(577, 303);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Processor";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(630, 364);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "RAM";
            // 
            // lblProp1
            // 
            this.lblProp1.AutoSize = true;
            this.lblProp1.Location = new System.Drawing.Point(813, 298);
            this.lblProp1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProp1.Name = "lblProp1";
            this.lblProp1.Size = new System.Drawing.Size(99, 20);
            this.lblProp1.TabIndex = 14;
            this.lblProp1.Text = "All in One";
            this.lblProp1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProp2
            // 
            this.lblProp2.AutoSize = true;
            this.lblProp2.Location = new System.Drawing.Point(840, 234);
            this.lblProp2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProp2.Name = "lblProp2";
            this.lblProp2.Size = new System.Drawing.Size(72, 20);
            this.lblProp2.TabIndex = 15;
            this.lblProp2.Text = "Graphic";
            this.lblProp2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(840, 359);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "Price $";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(668, 502);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 30);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(785, 502);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 30);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(899, 502);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(90, 30);
            this.btnRemove.TabIndex = 11;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "Admin : ";
            // 
            // lblAdminName
            // 
            this.lblAdminName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAdminName.Location = new System.Drawing.Point(81, 17);
            this.lblAdminName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAdminName.Name = "lblAdminName";
            this.lblAdminName.Size = new System.Drawing.Size(196, 28);
            this.lblAdminName.TabIndex = 21;
            this.lblAdminName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(296, 22);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "Hiring Date: ";
            // 
            // lblHiringDate
            // 
            this.lblHiringDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHiringDate.Location = new System.Drawing.Point(419, 17);
            this.lblHiringDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHiringDate.Name = "lblHiringDate";
            this.lblHiringDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHiringDate.Size = new System.Drawing.Size(112, 28);
            this.lblHiringDate.TabIndex = 23;
            this.lblHiringDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 65);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(171, 20);
            this.label14.TabIndex = 24;
            this.label14.Text = "Years At Company: ";
            // 
            // lblYearsAtCompany
            // 
            this.lblYearsAtCompany.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblYearsAtCompany.Location = new System.Drawing.Point(180, 59);
            this.lblYearsAtCompany.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYearsAtCompany.Name = "lblYearsAtCompany";
            this.lblYearsAtCompany.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblYearsAtCompany.Size = new System.Drawing.Size(97, 27);
            this.lblYearsAtCompany.TabIndex = 25;
            this.lblYearsAtCompany.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInStock
            // 
            this.txtInStock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInStock.Location = new System.Drawing.Point(920, 164);
            this.txtInStock.Margin = new System.Windows.Forms.Padding(4);
            this.txtInStock.Name = "txtInStock";
            this.txtInStock.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtInStock.Size = new System.Drawing.Size(112, 27);
            this.txtInStock.TabIndex = 5;
            this.txtInStock.Tag = "Code";
            this.txtInStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(831, 171);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 20);
            this.label12.TabIndex = 27;
            this.label12.Text = "In Stock";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(312, 65);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 20);
            this.label19.TabIndex = 28;
            this.label19.Text = "Category:";
            // 
            // lblCategory
            // 
            this.lblCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCategory.Location = new System.Drawing.Point(400, 59);
            this.lblCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblCategory.Size = new System.Drawing.Size(131, 27);
            this.lblCategory.TabIndex = 29;
            this.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::RogersKwon.Properties.Resources._699234;
            this.pictureBox3.Location = new System.Drawing.Point(989, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 563);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtInStock);
            this.Controls.Add(this.lblYearsAtCompany);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblHiringDate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblAdminName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.tbcAdmin);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBrand);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtProcessor);
            this.Controls.Add(this.txtRam);
            this.Controls.Add(this.txtProp1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtProp2);
            this.Controls.Add(this.lblProp2);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.lblProp1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminFormRogersKwon";
            this.tbcAdmin.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbcAdmin;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox lstDesktops;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtBrand;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtProcessor;
        private System.Windows.Forms.TextBox txtRam;
        private System.Windows.Forms.TextBox txtProp1;
        private System.Windows.Forms.TextBox txtProp2;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblProp1;
        private System.Windows.Forms.Label lblProp2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstLaptops;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAdminName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblHiringDate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblYearsAtCompany;
        private System.Windows.Forms.TextBox txtInStock;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}