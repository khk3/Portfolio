﻿namespace RogersKwon
{
    partial class Captcha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Captcha));
            this.label3 = new System.Windows.Forms.Label();
            this.txtRandom = new System.Windows.Forms.TextBox();
            this.btnCaptcha = new System.Windows.Forms.Button();
            this.lblRandom = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNewCaptcha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(453, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Put the key here: ";
            // 
            // txtRandom
            // 
            this.txtRandom.Location = new System.Drawing.Point(599, 94);
            this.txtRandom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRandom.Name = "txtRandom";
            this.txtRandom.Size = new System.Drawing.Size(100, 22);
            this.txtRandom.TabIndex = 0;
            // 
            // btnCaptcha
            // 
            this.btnCaptcha.Location = new System.Drawing.Point(540, 143);
            this.btnCaptcha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCaptcha.Name = "btnCaptcha";
            this.btnCaptcha.Size = new System.Drawing.Size(75, 23);
            this.btnCaptcha.TabIndex = 1;
            this.btnCaptcha.Text = "Confirm ";
            this.btnCaptcha.UseVisualStyleBackColor = true;
            this.btnCaptcha.Click += new System.EventHandler(this.btnCaptcha_Click);
            // 
            // lblRandom
            // 
            this.lblRandom.BackColor = System.Drawing.Color.White;
            this.lblRandom.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRandom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRandom.Image = ((System.Drawing.Image)(resources.GetObject("lblRandom.Image")));
            this.lblRandom.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblRandom.Location = new System.Drawing.Point(139, 92);
            this.lblRandom.Name = "lblRandom";
            this.lblRandom.Size = new System.Drawing.Size(285, 74);
            this.lblRandom.TabIndex = 2;
            this.lblRandom.Text = "captcha";
            this.lblRandom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Confirm you are a Human.";
            // 
            // btnNewCaptcha
            // 
            this.btnNewCaptcha.Image = ((System.Drawing.Image)(resources.GetObject("btnNewCaptcha.Image")));
            this.btnNewCaptcha.Location = new System.Drawing.Point(31, 92);
            this.btnNewCaptcha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNewCaptcha.Name = "btnNewCaptcha";
            this.btnNewCaptcha.Size = new System.Drawing.Size(80, 74);
            this.btnNewCaptcha.TabIndex = 4;
            this.btnNewCaptcha.UseVisualStyleBackColor = true;
            this.btnNewCaptcha.Click += new System.EventHandler(this.btnNewCaptcha_Click);
            // 
            // Captcha
            // 
            this.AcceptButton = this.btnCaptcha;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 209);
            this.Controls.Add(this.lblRandom);
            this.Controls.Add(this.btnNewCaptcha);
            this.Controls.Add(this.btnCaptcha);
            this.Controls.Add(this.txtRandom);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Captcha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CaptchaRogersKwon";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRandom;
        private System.Windows.Forms.Button btnCaptcha;
        private System.Windows.Forms.Label lblRandom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNewCaptcha;
    }
}