﻿namespace RogersKwon
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblStock = new System.Windows.Forms.Label();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cboQuantity = new System.Windows.Forms.ComboBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lstOrder = new System.Windows.Forms.ListBox();
            this.ofdConfirm = new System.Windows.Forms.OpenFileDialog();
            this.tabComputers = new System.Windows.Forms.TabControl();
            this.tabDesktops = new System.Windows.Forms.TabPage();
            this.lstDesktops = new System.Windows.Forms.ListBox();
            this.tabLaptops = new System.Windows.Forms.TabPage();
            this.lstLaptops = new System.Windows.Forms.ListBox();
            this.lblTotalDisplay = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblMembership = new System.Windows.Forms.Label();
            this.btnDiscount = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabComputers.SuspendLayout();
            this.tabDesktops.SuspendLayout();
            this.tabLaptops.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.Location = new System.Drawing.Point(579, 318);
            this.btnConfirmOrder.Margin = new System.Windows.Forms.Padding(2);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(56, 29);
            this.btnConfirmOrder.TabIndex = 4;
            this.btnConfirmOrder.Text = "Confirm";
            this.btnConfirmOrder.UseVisualStyleBackColor = true;
            this.btnConfirmOrder.Click += new System.EventHandler(this.btnConfirmOrder_Click_1);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(490, 319);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(56, 29);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(405, 318);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(56, 29);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblStock);
            this.groupBox1.Controls.Add(this.lblAvailable);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.cboQuantity);
            this.groupBox1.Controls.Add(this.lblProduct);
            this.groupBox1.Location = new System.Drawing.Point(397, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(249, 268);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // lblStock
            // 
            this.lblStock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStock.Location = new System.Drawing.Point(81, 227);
            this.lblStock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(134, 13);
            this.lblStock.TabIndex = 36;
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.Location = new System.Drawing.Point(34, 227);
            this.lblAvailable.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(38, 13);
            this.lblAvailable.TabIndex = 35;
            this.lblAvailable.Text = "Stock:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(22, 22);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 29;
            this.label19.Text = "Quantity";
            // 
            // cboQuantity
            // 
            this.cboQuantity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQuantity.FormattingEnabled = true;
            this.cboQuantity.Location = new System.Drawing.Point(85, 14);
            this.cboQuantity.Name = "cboQuantity";
            this.cboQuantity.Size = new System.Drawing.Size(131, 21);
            this.cboQuantity.TabIndex = 32;
            // 
            // lblProduct
            // 
            this.lblProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProduct.Location = new System.Drawing.Point(6, 55);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(237, 210);
            this.lblProduct.TabIndex = 31;
            // 
            // lstOrder
            // 
            this.lstOrder.FormattingEnabled = true;
            this.lstOrder.Location = new System.Drawing.Point(651, 68);
            this.lstOrder.Margin = new System.Windows.Forms.Padding(2);
            this.lstOrder.Name = "lstOrder";
            this.lstOrder.Size = new System.Drawing.Size(296, 277);
            this.lstOrder.TabIndex = 11;
            // 
            // ofdConfirm
            // 
            this.ofdConfirm.FileName = "openFileDialog1";
            // 
            // tabComputers
            // 
            this.tabComputers.Controls.Add(this.tabDesktops);
            this.tabComputers.Controls.Add(this.tabLaptops);
            this.tabComputers.Location = new System.Drawing.Point(11, 46);
            this.tabComputers.Margin = new System.Windows.Forms.Padding(2);
            this.tabComputers.Name = "tabComputers";
            this.tabComputers.SelectedIndex = 0;
            this.tabComputers.Size = new System.Drawing.Size(381, 330);
            this.tabComputers.TabIndex = 37;
            this.tabComputers.SelectedIndexChanged += new System.EventHandler(this.tabComputers_SelectedIndexChanged);
            // 
            // tabDesktops
            // 
            this.tabDesktops.Controls.Add(this.lstDesktops);
            this.tabDesktops.Location = new System.Drawing.Point(4, 22);
            this.tabDesktops.Margin = new System.Windows.Forms.Padding(2);
            this.tabDesktops.Name = "tabDesktops";
            this.tabDesktops.Padding = new System.Windows.Forms.Padding(2);
            this.tabDesktops.Size = new System.Drawing.Size(373, 304);
            this.tabDesktops.TabIndex = 0;
            this.tabDesktops.Text = "Desktops";
            this.tabDesktops.UseVisualStyleBackColor = true;
            // 
            // lstDesktops
            // 
            this.lstDesktops.FormattingEnabled = true;
            this.lstDesktops.Location = new System.Drawing.Point(15, 11);
            this.lstDesktops.Name = "lstDesktops";
            this.lstDesktops.Size = new System.Drawing.Size(342, 316);
            this.lstDesktops.TabIndex = 1;
            this.lstDesktops.SelectedIndexChanged += new System.EventHandler(this.lstDesktops_SelectedIndexChanged_1);
            // 
            // tabLaptops
            // 
            this.tabLaptops.Controls.Add(this.lstLaptops);
            this.tabLaptops.Location = new System.Drawing.Point(4, 22);
            this.tabLaptops.Margin = new System.Windows.Forms.Padding(2);
            this.tabLaptops.Name = "tabLaptops";
            this.tabLaptops.Padding = new System.Windows.Forms.Padding(2);
            this.tabLaptops.Size = new System.Drawing.Size(373, 304);
            this.tabLaptops.TabIndex = 1;
            this.tabLaptops.Text = "Laptops";
            this.tabLaptops.UseVisualStyleBackColor = true;
            // 
            // lstLaptops
            // 
            this.lstLaptops.FormattingEnabled = true;
            this.lstLaptops.Location = new System.Drawing.Point(15, 12);
            this.lstLaptops.Name = "lstLaptops";
            this.lstLaptops.Size = new System.Drawing.Size(342, 316);
            this.lstLaptops.TabIndex = 0;
            this.lstLaptops.SelectedIndexChanged += new System.EventHandler(this.lstLaptops_SelectedIndexChanged);
            // 
            // lblTotalDisplay
            // 
            this.lblTotalDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalDisplay.Location = new System.Drawing.Point(754, 359);
            this.lblTotalDisplay.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalDisplay.Name = "lblTotalDisplay";
            this.lblTotalDisplay.Size = new System.Drawing.Size(143, 13);
            this.lblTotalDisplay.TabIndex = 39;
            // 
            // lblCustomer
            // 
            this.lblCustomer.Location = new System.Drawing.Point(45, 9);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(216, 23);
            this.lblCustomer.TabIndex = 40;
            // 
            // lblMembership
            // 
            this.lblMembership.AutoSize = true;
            this.lblMembership.Location = new System.Drawing.Point(337, 19);
            this.lblMembership.Name = "lblMembership";
            this.lblMembership.Size = new System.Drawing.Size(35, 13);
            this.lblMembership.TabIndex = 41;
            this.lblMembership.Text = "label1";
            // 
            // btnDiscount
            // 
            this.btnDiscount.Location = new System.Drawing.Point(754, 28);
            this.btnDiscount.Name = "btnDiscount";
            this.btnDiscount.Size = new System.Drawing.Size(103, 23);
            this.btnDiscount.TabIndex = 42;
            this.btnDiscount.Text = "Apply Discount";
            this.btnDiscount.UseVisualStyleBackColor = true;
            this.btnDiscount.Click += new System.EventHandler(this.btnDiscount_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(680, 362);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(34, 13);
            this.lblTotal.TabIndex = 43;
            this.lblTotal.Text = "Total:";
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 441);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnDiscount);
            this.Controls.Add(this.lblMembership);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblTotalDisplay);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnConfirmOrder);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lstOrder);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.tabComputers);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CustomerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CustomerFormRogersKwon";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabComputers.ResumeLayout(false);
            this.tabDesktops.ResumeLayout(false);
            this.tabLaptops.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.ListBox lstOrder;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ComboBox cboQuantity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.OpenFileDialog ofdConfirm;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.TabControl tabComputers;
        private System.Windows.Forms.TabPage tabDesktops;
        private System.Windows.Forms.TabPage tabLaptops;
        private System.Windows.Forms.ListBox lstDesktops;
        private System.Windows.Forms.ListBox lstLaptops;
        private System.Windows.Forms.Label lblTotalDisplay;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblMembership;
        private System.Windows.Forms.Button btnDiscount;
        private System.Windows.Forms.Label lblTotal;
    }
}