﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RogersKwon
{
    public partial class AdminForm : Form
    {
        List<Desktop> desktops = new List<Desktop>();
        List<Laptop> laptops = new List<Laptop>();
        List<Computer> inventory = new List<Computer>();

        public AdminForm() { }

        public AdminForm(Admin admin)//admin info sent after login
        {
            InitializeComponent();
            //store the user sent from loginForm to            
            lblAdminName.Text= admin.FirstName + " " + admin.LastName;
            lblHiringDate.Text = admin.HiredDate;
            lblYearsAtCompany.Text = admin.YearsAtCompany.ToString();
            lblCategory.Text = admin.Category;
            //store the lists of products
            desktops = CompanyDB.GetDesktops();
            laptops = CompanyDB.GetLaptops();
            inventory.AddRange(desktops);
            inventory.AddRange(laptops);

            DisplayProduct();
        }

        private void DisplayProduct()
        {
            // Clear both listboxes if item was added
            lstDesktops.Items.Clear();
            lstLaptops.Items.Clear();

            // Add computers to list of items
            foreach (Desktop desktop in desktops)
            {
                lstDesktops.Items.Add(String.Format(
                    "{0,-15}{1,-10}{2,-10}{3,-10}{4,-15}{5,10}", "(" + desktop.GetType().Name + ")", desktop.InStock, desktop.Code, desktop.Brand, desktop.Model, desktop.Price.ToString("C2")));
            }
            foreach (Laptop laptop in laptops)
            {
                lstLaptops.Items.Add(String.Format(
                    "{0,-15}{1,-10}{2,-10}{3,-10}{4,-15}{5,10}", "(" + laptop.GetType().Name + ")", laptop.InStock,laptop.Code, laptop.Brand, laptop.Model, laptop.Price.ToString("C2")));
            }
        }//end of DisplayProduct

        private void lstDesktops_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tbcAdmin.Controls[0] == tbcAdmin.SelectedTab && lstDesktops.SelectedIndex != -1)
            {     
                int index = lstDesktops.SelectedIndex;
                txtCode.Text = desktops[index].Code.ToString();
                txtBrand.Text = desktops[index].Brand.ToString();
                txtModel.Text = desktops[index].Model.ToString();
                txtProcessor.Text = desktops[index].Processor.ToString();
                txtRam.Text = desktops[index].Ram.ToString();
                txtProp1.Text = desktops[index].AllInOne.ToString();
                lblProp2.Text = "Graphic";
                txtProp2.Text = desktops[index].Graphic.ToString();
                txtPrice.Text = desktops[index].Price.ToString();
                txtInStock.Text= desktops[index].InStock.ToString();
            }       
        }

        private void lstLaptops_SelectedIndexChanged(object sender, EventArgs e)
        {
            //lstDesktops.SelectedIndex = -1;
            if(tbcAdmin.Controls[1] == tbcAdmin.SelectedTab && lstLaptops.SelectedIndex !=-1)
            {
                int index = lstLaptops.SelectedIndex;
                txtCode.Text = laptops[index].Code.ToString();
                txtBrand.Text = laptops[index].Brand.ToString();
                txtModel.Text = laptops[index].Model.ToString();
                txtProcessor.Text = laptops[index].Processor.ToString();
                txtRam.Text = laptops[index].Ram.ToString();
                lblProp1.Text = "ScreenSize";
                txtProp1.Text = laptops[index].ScreenSize.ToString();
                lblProp2.Text = "Battery";
                txtProp2.Text = laptops[index].Battery.ToString();
                txtPrice.Text = laptops[index].Price.ToString();
                txtInStock.Text = laptops[index].InStock.ToString();
            }

        }//end of lstLaptops SelectedIndexChange  

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(tbcAdmin.Controls[0] == tbcAdmin.SelectedTab && lstDesktops.SelectedIndex!=-1)
            {
                //lstLaptops.SelectedIndex = -1;
                if (ValidateDesktop())
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Update?", "Confirm Update", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes && lstDesktops.SelectedIndex != -1)
                    {
                        UpdateDesktop();                                    
                    }
                    DisplayProduct();
                    ClearTextboxes();
                }

            }
            else if(tbcAdmin.Controls[1] == tbcAdmin.SelectedTab && lstLaptops.SelectedIndex !=-1)
            {
                //lstDesktops.SelectedIndex =- 1;
                if(ValidateLaptop())
                 {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Update?", "Confirm Update", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes && lstLaptops.SelectedIndex != -1)
                    {
                        UpdateLaptop();
                                          
                    }
                    DisplayProduct();
                    ClearTextboxes();
                 }
            }        
        }

        //method to update Desktop Info
        private void UpdateDesktop()
        {
            int index = lstDesktops.SelectedIndex;
            desktops[index].Code = Convert.ToInt32(txtCode.Text);
            desktops[index].Brand = txtBrand.Text;
            desktops[index].Model = txtModel.Text;
            desktops[index].Processor = txtProcessor.Text;
            desktops[index].Ram = Convert.ToInt32(txtRam.Text);
            desktops[index].AllInOne = Convert.ToBoolean(txtProp1.Text);
            desktops[index].Graphic = txtProp2.Text;
            desktops[index].Price = Convert.ToDecimal(txtPrice.Text);
            desktops[index].InStock = Convert.ToInt32(txtInStock.Text);
        }

        //method to update the laptop info
        private void UpdateLaptop()
        {
            int index = lstLaptops.SelectedIndex;
            laptops[index].Code = Convert.ToInt32(txtCode.Text);
            laptops[index].Brand = txtBrand.Text;
            laptops[index].Model = txtModel.Text;
            laptops[index].Processor = txtProcessor.Text;
            laptops[index].Ram = Convert.ToInt32(txtRam.Text);
            laptops[index].ScreenSize = Convert.ToDouble(txtProp1.Text);
            laptops[index].Battery = Convert.ToInt32(txtProp2.Text);
            laptops[index].Price = Convert.ToDecimal(txtPrice.Text);
            laptops[index].InStock = Convert.ToInt32(txtInStock.Text);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {   //if tab Desktop
            if (tbcAdmin.SelectedIndex==0)
            {
                if (ValidateDesktop())
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Add?", "Confirm Add", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Desktop newDesktop = new Desktop();
                        newDesktop.Code = Convert.ToInt32(txtCode.Text);
                        newDesktop.Brand = txtBrand.Text;
                        newDesktop.Model = txtModel.Text;
                        newDesktop.Processor = txtProcessor.Text;
                        newDesktop.Ram = Convert.ToInt32(txtRam.Text);
                        newDesktop.AllInOne = Convert.ToBoolean(txtProp1.Text);
                        newDesktop.Graphic = txtProp2.Text;
                        newDesktop.Price = Convert.ToDecimal(txtPrice.Text);
                        newDesktop.InStock= Convert.ToInt32(txtInStock.Text);

                        bool inList = false;
                        foreach(Desktop d in desktops)
                        {
                            if(d == newDesktop)// using the overloaded relational operator 
                            {
                                
                                inList = true;
                                txtInStock.Text= (d+newDesktop).ToString();//using overloaded math operator 
                            }
                                                     
                        }
                        if (inList == false)
                          desktops.Add(newDesktop);
                        //add desktop to XML file
                        CompanyDB.SaveDesktops(desktops);
                        //update the listboxes
                        DisplayProduct();
                        ClearTextboxes();
                    }                      
                }                  
            }
            //If tab Laptops
            else if (tbcAdmin.SelectedIndex == 1)
            {
                if (ValidateLaptop())
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Add?", "Confirm Add", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Laptop newLaptop = new Laptop();
                        newLaptop.Code = Convert.ToInt32(txtCode.Text);
                        newLaptop.Brand = txtBrand.Text;
                        newLaptop.Model = txtModel.Text;
                        newLaptop.Processor = txtProcessor.Text;
                        newLaptop.Ram = Convert.ToInt32(txtRam.Text);
                        newLaptop.ScreenSize = Convert.ToDouble(txtProp1.Text);
                        newLaptop.Battery = Convert.ToInt32(txtProp2.Text);
                        newLaptop.Price = Convert.ToDecimal(txtPrice.Text);

                        bool inList = false;
                        foreach (Laptop l in laptops)
                        {
                            if (l == newLaptop)
                            {                             
                                inList = true;
                                txtInStock.Text = (l + newLaptop).ToString(); //overload math operator +
                            }
                        }
                        if (inList == false)
                            laptops.Add(newLaptop);

                        CompanyDB.SaveLaptops(laptops);
                        DisplayProduct();
                        ClearTextboxes();
                    }                    
                }
            }
        }

        private bool ValidateDesktop()
        {
            bool valid = false;
            if (Validator.IsPresent(txtCode) && Validator.IsPresent(txtBrand) && Validator.IsPresent(txtModel) &&
                Validator.IsPresent(txtProcessor) && Validator.IsPresent(txtRam) && Validator.IsPresent(txtProp1) &&
                Validator.IsPresent(txtProp2) && Validator.IsPresent(txtPrice) && Validator.IsInt32(txtCode) &&
                Validator.IsInt32(txtRam) && Validator.IsDecimal(txtPrice) && Validator.IsBool(txtProp1) &&
                Validator.IsInt32(txtInStock))
            {
                 valid = ValidateCode();
            }
            return valid;                                         
        }//end of validator Desktop

        private bool ValidateLaptop()
        {
            bool valid = false;
            if (Validator.IsPresent(txtCode) && Validator.IsPresent(txtBrand) && Validator.IsPresent(txtModel) &&
                Validator.IsPresent(txtProcessor) && Validator.IsPresent(txtRam) && Validator.IsDouble(txtProp1) &&
                Validator.IsInt32(txtProp2) && Validator.IsPresent(txtPrice) && Validator.IsInt32(txtCode) &&
                Validator.IsInt32(txtRam) && Validator.IsDecimal(txtPrice)&& Validator.IsInt32(txtInStock))
            {
                valid = ValidateCode();
            }
            return valid;
        }

        private bool ValidateCode()
        {
            bool valid = false;
            switch (Validator.NoCodeRepeat(inventory, Convert.ToInt32(txtCode.Text)))
            {
                case true:
                    MessageBox.Show("This Product ID is already in use.\n" +
                                    "ID's must be unique acrosss all items", "Item ID error");
                    valid = false;
                    break;
                case false:
                    valid = true;
                    break;
            }
            return valid;
        }

        private void tbcAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearTextboxes();
            if (tbcAdmin.Controls[0] == tbcAdmin.SelectedTab)
            {
                lblProp1.Text = "AllInOne";
                lblProp2.Text = "Graphics";
            }
            else if (tbcAdmin.Controls[1] == tbcAdmin.SelectedTab)
            {
                lblProp1.Text = "ScreenSize";
                lblProp2.Text = "Battery";
            }
        }

        private void ClearTextboxes()
        {
            txtCode.Text = "";
            txtBrand.Text = "";
            txtModel.Text = "";
            txtProcessor.Text = "";
            txtProp1.Text = "";
            txtProp2.Text = "";
            txtPrice.Text = "";
            txtRam.Text = "";
            txtInStock.Text = "";          
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (tbcAdmin.Controls[0] == tbcAdmin.SelectedTab)
            {   //Remove only if there is more than 1
                if(lstDesktops.SelectedIndex != -1 && lstDesktops.Items.Count>1)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Remove?", "Confirm Remove", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        //remove the product from the list
                        desktops.RemoveAt(lstDesktops.SelectedIndex);
                        //save XML file with the new list
                        CompanyDB.SaveDesktops(desktops);
                        //display the list updated
                        DisplayProduct();
                    }                       
                }
            }
            else if (tbcAdmin.Controls[1] == tbcAdmin.SelectedTab)
            {   //Remove only if there is more than 1
                if (lstLaptops.SelectedIndex != -1 && lstLaptops.Items.Count>1)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Remove?", "Confirm Remove", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        //remove the product from the list
                        laptops.RemoveAt(lstLaptops.SelectedIndex);
                        //save XML file with the new list
                        CompanyDB.SaveLaptops(laptops);
                        //display the list updated
                        DisplayProduct();
                    }                   
                }
            }
        }//end of Remove Method            
    }//end of class
}
