﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace RogersKwon
{
    //Static Class CompanyDB: Helper class for file validation
    //Written by Noah and Kang
    public static class CompanyDB
    {
        //Written by Noah and Kang
        //Method: GetUsers(string filePath)
        //Sent: (string filePath)
        //Data returned: List<Users>
        //Description:Creates new list to store users read from .xml file. Creates new users for each object in file.
        public static List<Users> GetUsers(string userFilePath)
        {
            // Create the List
            List<Users> users = new List<Users>();

            // create XmlReaderSettings object
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;

                // create the XmlReader object
                XmlReader xmlIn = XmlReader.Create(userFilePath, settings);

                //Read to first node of record
                if (xmlIn.ReadToDescendant("record"))
                {
                    // create one user for each node
                    do
                    {   //read start element, set content into variables
                        xmlIn.ReadStartElement("record");
                        string firstName = xmlIn.ReadElementContentAsString();
                        string lastName = xmlIn.ReadElementContentAsString();
                        string login = xmlIn.ReadElementContentAsString();
                        string password = xmlIn.ReadElementContentAsString();
                        bool access = xmlIn.ReadElementContentAsBoolean();

                        //validate access to decide which User to create
                        if (!access) //User is a customer
                        {
                            // Set Loyalty
                            bool loyalty = xmlIn.ReadElementContentAsBoolean();

                            // create Customer Object with custom constructor and add to users
                            Customer customer = new Customer(lastName, firstName, login, password, access, loyalty);
                            users.Add(customer);

                        }
                        else if (access) //User is an admin
                        {
                            // Set hire Date and years
                            string hireDate = xmlIn.ReadElementContentAsString();
                            int yearsAtCompany = xmlIn.ReadElementContentAsInt();

                        // create Admin Object with custom constructor and add to users
                        Admin admin = new Admin(lastName, firstName, login, password, access, hireDate, yearsAtCompany);
                            users.Add(admin);
                        }

                    }
                    while (xmlIn.ReadToNextSibling("record")); //Read while Next Sibling is 'record'


                }
            //close reader
            xmlIn.Close();
            //return list
            return users;
        }//end of GetUsers

        //Written by Noah
        //Method: GetDesktops(string filePath)
        //Sent: (string filePath)
        //Data returned: List<Desktops>
        //Description:Creates new list to store desktops read from .xml file. Creates new desktops for each object in file.
        public static List<Desktop> GetDesktops()
        {
        // Create the List
        List<Desktop> desktops = new List<Desktop>();

        // create XmlReaderSettings object
        string path = @"c:\files\desktops.xml";
        XmlReaderSettings settings = new XmlReaderSettings();
        settings.IgnoreWhitespace = true;
        settings.IgnoreComments = true;

        // create the XmlReader object
        XmlReader xmlIn = XmlReader.Create(path, settings);

        //Read to first node of record
        if (xmlIn.ReadToDescendant("Desktop"))
        {
            // create one Product object for each record
            do
            {   //Create desktops, set properties from data read, add to List
                Desktop desktop = new Desktop();
                xmlIn.ReadStartElement("Desktop");
                desktop.Code = xmlIn.ReadElementContentAsInt();
                desktop.InStock = xmlIn.ReadElementContentAsInt();
                desktop.Brand = xmlIn.ReadElementContentAsString();
                desktop.Model = xmlIn.ReadElementContentAsString();
                desktop.Processor = xmlIn.ReadElementContentAsString();
                desktop.Price = xmlIn.ReadElementContentAsDecimal();
                desktop.Ram = xmlIn.ReadElementContentAsInt();
                desktop.AllInOne = xmlIn.ReadElementContentAsBoolean();
                desktop.Graphic = xmlIn.ReadElementContentAsString();
                desktops.Add(desktop);
            }
            while (xmlIn.ReadToNextSibling("Desktop")); //Read while Next Sibling is 'desktop'

        }

        //close reader
        xmlIn.Close();
        //return list
        return desktops;
        }   //End of GetDesktops()

        //Written by Noah
        //Method: GetDesktops(string filePath)
        //Sent: (string filePath)
        //Data returned: List<Laptops>
        //Description:Creates new list to store laptops read from .xml file. Creates new laptops for each object in file.
        public static List<Laptop> GetLaptops()
        {
            // Create the List
            List<Laptop> laptops = new List<Laptop>();

            // create XmlReaderSettings object
            string path = @"c:\files\laptops.xml";
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;

            // create the XmlReader object
            XmlReader xmlIn = XmlReader.Create(path, settings);

            //Read to first node of record
            if (xmlIn.ReadToDescendant("Laptop"))
            {
                // create one Product object for each
                do
                {   //Create lapktops, set properties from data read, add to List
                    Laptop laptop = new Laptop();
                    xmlIn.ReadStartElement("Laptop");
                    laptop.Code = xmlIn.ReadElementContentAsInt();
                    laptop.InStock = xmlIn.ReadElementContentAsInt();
                    laptop.Brand = xmlIn.ReadElementContentAsString();
                    laptop.Model = xmlIn.ReadElementContentAsString();
                    laptop.Processor = xmlIn.ReadElementContentAsString();
                    laptop.Price = xmlIn.ReadElementContentAsDecimal();
                    laptop.Ram = xmlIn.ReadElementContentAsInt();
                    laptop.ScreenSize = xmlIn.ReadElementContentAsDouble();
                    laptop.Battery = xmlIn.ReadElementContentAsInt();
                    laptops.Add(laptop);
                }
                while (xmlIn.ReadToNextSibling("Laptop")); //Read while Next Sibling is 'laptop'

            }
            //close reader
            xmlIn.Close();
            //return list
            return laptops;
        }

        //Written by Noah
        //Method: SaveDesktops(string filePath)
        //Sent: (List <Desktops>)
        //Data returned: Nothing
        //Description: Called from an order being placed by a customer.
        public static void SaveDesktops(List<Desktop> desktops)
        {
            // create the XmlWriterSettings object
            string path = @"c:\files\desktops2.xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = ("    ");

            // create the XmlWriter object
            XmlWriter xmlOut = XmlWriter.Create(path, settings);

            // write the start of the document
            xmlOut.WriteStartDocument();
            xmlOut.WriteStartElement("Computers");

            // write each product object to the xml file
            foreach (Desktop desktop in desktops)
            {
                xmlOut.WriteStartElement("Desktop");
                xmlOut.WriteElementString("Code", Convert.ToString(desktop.Code));
                xmlOut.WriteElementString("inStock", Convert.ToString(desktop.InStock));
                xmlOut.WriteElementString("Brand", Convert.ToString(desktop.Brand));
                xmlOut.WriteElementString("Model", desktop.Model);
                xmlOut.WriteElementString("Processor", desktop.Processor);
                xmlOut.WriteElementString("Price", Convert.ToString(desktop.Price));
                xmlOut.WriteElementString("Ram", Convert.ToString(desktop.Ram));
                xmlOut.WriteElementString("AllInOne", Convert.ToString(desktop.AllInOne));
                xmlOut.WriteElementString("Graphic", Convert.ToString(desktop.Graphic));

                xmlOut.WriteEndElement();
            }

            // write the end tag for the root element
            xmlOut.WriteEndElement();

            // close the xmlWriter object
            xmlOut.Close();
        }

        public static void SaveLaptops(List<Laptop> laptops)
        {
            // create the XmlWriterSettings object
            string path = @"c:\files\laptops2.xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = ("    ");

            // create the XmlWriter object
            XmlWriter xmlOut = XmlWriter.Create(path, settings);

            // write the start of the document
            xmlOut.WriteStartDocument();
            xmlOut.WriteStartElement("Computers");

            // write each product object to the xml file
            foreach (Laptop laptop in laptops)
            {
                xmlOut.WriteStartElement("Laptop");
                xmlOut.WriteElementString("Code", Convert.ToString(laptop.Code));
                xmlOut.WriteElementString("InStock", Convert.ToString(laptop.InStock));
                xmlOut.WriteElementString("Brand", Convert.ToString(laptop.Brand));
                xmlOut.WriteElementString("Model", laptop.Model);
                xmlOut.WriteElementString("Processor", laptop.Processor);
                xmlOut.WriteElementString("Price", Convert.ToString(laptop.Price));
                xmlOut.WriteElementString("Ram", Convert.ToString(laptop.Ram));
                xmlOut.WriteElementString("ScreenSize", Convert.ToString(laptop.ScreenSize));
                xmlOut.WriteElementString("Baterry", Convert.ToString(laptop.ScreenSize));
                xmlOut.WriteEndElement();
            }

            // write the end tag for the root element
            xmlOut.WriteEndElement();

            // close the xmlWriter object
            xmlOut.Close();
        }//end of save laptops

        public static void UpdateDesktops(List<Desktop> desktops)
        {
            // create the XmlWriterSettings object
            string path = @"c:\files\laptops2.xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = ("    ");

            // create the XmlWriter object
            XmlWriter xmlOut = XmlWriter.Create(path, settings);

            // write the start of the document
            xmlOut.WriteStartDocument();
            xmlOut.WriteStartElement("Computers");

            // write each product object to the xml file
            foreach (Desktop desktop in desktops)
            {
                xmlOut.WriteStartElement("Laptop");
                xmlOut.WriteElementString("Code", Convert.ToString(desktop.Code));
                xmlOut.WriteElementString("InStock", Convert.ToString(desktop.InStock));
                xmlOut.WriteElementString("Brand", Convert.ToString(desktop.Brand));
                xmlOut.WriteElementString("Model", desktop.Model);
                xmlOut.WriteElementString("Processor", desktop.Processor);
                xmlOut.WriteElementString("Price", Convert.ToString(desktop.Price));
                xmlOut.WriteElementString("Ram", Convert.ToString(desktop.Ram));
                xmlOut.WriteElementString("AllInOne", Convert.ToString(desktop.AllInOne));
                xmlOut.WriteElementString("Graphic", Convert.ToString(desktop.Graphic));
                xmlOut.WriteEndElement();
            }

            // write the end tag for the root element
            xmlOut.WriteEndElement();

            // close the xmlWriter object
            xmlOut.Close();
        }//end of updateDesktops


        public static void UpdateLaptops(List<Laptop> laptops)
        {
            // create the XmlWriterSettings object
            string path = @"c:\files\laptops2.xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = ("    ");

            // create the XmlWriter object
            XmlWriter xmlOut = XmlWriter.Create(path, settings);

            // write the start of the document
            xmlOut.WriteStartDocument();
            xmlOut.WriteStartElement("Computers");

            // write each product object to the xml file
            foreach (Laptop laptop in laptops)
            {
                xmlOut.WriteStartElement("Laptop");
                xmlOut.WriteElementString("Code", Convert.ToString(laptop.Code));
                xmlOut.WriteElementString("InStock", Convert.ToString(laptop.InStock));
                xmlOut.WriteElementString("Brand", Convert.ToString(laptop.Brand));
                xmlOut.WriteElementString("Model", laptop.Model);
                xmlOut.WriteElementString("Processor", laptop.Processor);
                xmlOut.WriteElementString("Price", Convert.ToString(laptop.Price));
                xmlOut.WriteElementString("Ram", Convert.ToString(laptop.Ram));
                xmlOut.WriteElementString("ScreenSize", Convert.ToString(laptop.ScreenSize));
                xmlOut.WriteElementString("Battery", Convert.ToString(laptop.Battery));
                xmlOut.WriteEndElement();
            }

            // write the end tag for the root element
            xmlOut.WriteEndElement();

            // close the xmlWriter object
            xmlOut.Close();
        }//end of updateLaptops



    }
}
