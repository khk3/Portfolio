﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace RogersKwon
{
    public partial class CustomerForm : Form
    {
        // user sent from login form
        public Users customer;

        // List of Products
        public List<Desktop> desktops = new List<Desktop>();      
        public List<Laptop> laptops = new List<Laptop>();

        // List of all the customers orders
        public List<Computer> cart = new List<Computer>();

        
        public CustomerForm(Customer user)
        {
            InitializeComponent();

            customer = user;
            lblCustomer.Text = "Welcome, " + user.FirstName;
            lblMembership.Text = user.LoyaltyMember ? "Loyalty Member" : HideMembership();

            // attempt to read from files
            desktops = CompanyDB.GetDesktops();
            laptops = CompanyDB.GetLaptops();

            //Display the Products in listboxs
            DisplayProduct();
        }

        private string HideMembership()
        {
            lblMembership.Hide();
            btnDiscount.Hide();
            return "";
        }

        private void DisplayProduct()
        {
            // Clear both listboxes if item was added
            lstDesktops.Items.Clear();
            lstLaptops.Items.Clear();

            // Add computers to list of items
           foreach(Desktop desktop in desktops)
            {
                lstDesktops.Items.Add(String.Format(
                    "{0,-15}{1,-20}{2,-18}{3,-20}{4,-15}", "(" + desktop.GetType().Name + ")", desktop.Brand, desktop.Model, desktop.InStock, desktop.Price.ToString("C2")));
            }
            foreach (
                Laptop laptop in laptops)
            
            {
                lstLaptops.Items.Add(String.Format(
                    "{0,-15}{1,-20}{2,-18}{3,-20}{4,-15}", "(" + laptop.GetType().Name + ")", laptop.Brand, laptop.Model, laptop.InStock, laptop.Price.ToString("C2")));
            }

        }

        private void QuantityDisplay(int available)
        {
            //Clear quantity Combobox
            cboQuantity.Items.Clear();

            switch (available < 1)
            {
                // if there is no stock, disbale quantity combobox
                case true:
                    cboQuantity.Enabled = false;
                    break;
                // if there is stock for selected item, enable and populate combobox, select quantity '1'
                case false:
                    cboQuantity.Enabled = true;
                    for (int i = 0; i < available; i++)
                    {
                        cboQuantity.Items.Add(i + 1);
                    }
                    cboQuantity.SelectedIndex = 0;
                    break;
            }
        }

        private void lstDesktops_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // shorthand for index, declare availability
            int index = lstDesktops.SelectedIndex;
            int available = 0;

            
            if (index != -1) 
            {
                // Update Label, set availability, must check if index is not -1
                lblProduct.Text = desktops[index].ToString();
                available = desktops[index].InStock;

                // update stock label
                lblStock.Text = desktops[index].InStock < 1 ? "Currently Unavailable" : desktops[index].InStock.ToString();
                // call Display mathod for Quantity
                QuantityDisplay(available);
            }
        }

        private void lstLaptops_SelectedIndexChanged(object sender, EventArgs e)
        {
            // shorthand variables
            int index = lstLaptops.SelectedIndex;
            int available = 0;

            if (index != -1)
            {
                lblProduct.Text = laptops[index].ToString();
                available = laptops[index].InStock;

                // update stock label
                lblStock.Text = laptops[index].InStock < 1 ? "Currently Unavailable" : laptops[index].InStock.ToString();
                // call Display mathod for Quantity
                QuantityDisplay(available);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int indexD = lstDesktops.SelectedIndex;
            int indexL = lstLaptops.SelectedIndex;
            int quantity = Convert.ToInt32(cboQuantity.SelectedIndex + 1);
            lblStock.Text = "";

            // if item is selected in desktop listbox
            if (indexD != -1)
            {
                // if the instock amount is greater than quantity selected
                if (desktops[indexD].InStock >= quantity && cboQuantity.SelectedIndex != -1)
                {
                    // decrease item InStock
                    desktops[indexD].InStock -= quantity;

                    // clone selected Computer and add to cart 
                    Computer clone = (Computer)desktops[indexD].Clone();
                    clone.Ordered = quantity;
                    cart.Add(clone);
                }
                else
                {
                    MessageBox.Show("There is no Stock available", "No Stock");
                }
                
            }
            // or if a laptop item is selected 
            else if (indexL != -1)
            {
                // if the instock amount is greater than quantity selected
                if (laptops[indexL].InStock >= quantity && cboQuantity.SelectedIndex != -1)
                {
                    // decrease item InStock
                    laptops[indexL].InStock -= quantity;

                    // construct a new Computer (custom constructor), add to orders
                    Computer clone = (Computer)laptops[indexL].Clone();
                    clone.Ordered = quantity;
                    cart.Add(clone);
                }
                else
                {
                    MessageBox.Show("There is no Stock available", "No Stock");
                }
            }

            // refresh products to show decrease in stock
            DisplayProduct();
            UpdateCart();

        }

        private void UpdateCart()
        {
            // Clear cart and reset label
            lstOrder.Items.Clear();
            // total variable
            decimal total = 0m;
            // Then update
            foreach(Computer computer in cart)
            {
                // Display product
                lstOrder.Items.Add(String.Format(
                    "{0,-10}{1,-20}{2,-6}{3,10}", "x" + computer.Ordered, computer.Brand, computer.Model, (computer.Ordered * computer.Price).ToString("C2")));
                // Total updated
                total += (computer.Ordered * computer.Price);
            }
            // add total to label
            lblTotalDisplay.Text = total.ToString("N2");
            // renable discount if change is made to cart
            btnDiscount.Enabled = true;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            // index shorthand
            int index = lstOrder.SelectedIndex;

            // index must be selected in order to remove an item
            if (index != -1)
            {
                // get product of order item for removal and quantity that was ordered
                int code = cart[index].Code;
                int ordered = cart[index].Ordered;

                // Compare code against both Lists of products, add back stock to item if removed from the cart
                foreach (Desktop desktop in desktops)
                {
                    if (desktop.Code == code)
                    {
                        desktop.InStock += ordered;
                    }
                }
                foreach (Laptop laptop in laptops)
                {
                    if (laptop.Code == code)
                    {
                        laptop.InStock += ordered;
                    }
                }

                // remove cart List
                cart.RemoveAt(index);
              
            }
            DisplayProduct();
            UpdateCart();
        }


        private void btnConfirmOrder_Click_1(object sender, EventArgs e)
        {
            DialogResult action = MessageBox.Show("Would you like to place this order?", "Confirm", MessageBoxButtons.YesNo);
            switch (action)
            {
                case DialogResult.Yes:

                    try
                    {
                        StreamWriter outputFile = new StreamWriter(@"c:/files/customerOrders.txt", true);
                        outputFile.WriteLine(String.Format("{0,-20}{1,-20}", "First Name: " + customer.FirstName, "Last Name: " + customer.LastName + "\n"));

                        foreach(Computer item in cart)
                        {
                            outputFile.WriteLine(String.Format("{0,-12}{1,-10}{2,-20}{3,-5}{4,-10}", "\t" + "ID." + item.Code, item.Brand, item.Model, "x. " + item.Ordered, (item.Ordered * item.Price).ToString("C2")));
                        }

                        outputFile.WriteLine("\n\t" + lblTotalDisplay.Text + "\n");

                        outputFile.Close();

                        // Clear the order, redisplay all lists
                        cart.Clear();
                        DisplayProduct();
                        UpdateCart();



                        CompanyDB.SaveLaptops(laptops);
                        CompanyDB.SaveDesktops(desktops);

                        MessageBox.Show("Your order has been placed", "Confirm");

                    }
                    catch
                    {
                        MessageBox.Show("An error occured", "Error");
                    }
                    // updates desktops in the 'database'
                    CompanyDB.SaveDesktops(desktops);
                    CompanyDB.SaveLaptops(laptops);
                    break;
                case DialogResult.No:
                    break;

            }
        }

        private void tabComputers_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(tabComputers.SelectedIndex)
            {
                case 0:
                    DisplayProduct();
                    lstLaptops.Items.Clear();
                    break;
                case 1:
                    DisplayProduct();
                    lstDesktops.Items.Clear();
                    break;
            }
        }

        private void CustomerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(cart.Count > 0)
            {
                DialogResult formClose = MessageBox.Show("You currently have items saved to your cart.\n" +
                                                         "~Company Name~ cannot guarantee the availability of these items until a purchase has been made.\n" +
                                                         "These items will not be Saved.\n\n" +
                                                         "Are you sure you wish to Logout?", "Confirm Close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (formClose == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        private void btnDiscount_Click(object sender, EventArgs e)
        {
            double total = Convert.ToDouble(lblTotalDisplay.Text);
            switch(total > 5000.00)
            {
                case true:
                    lblTotalDisplay.Text = (total * 0.9).ToString("C2");
                    btnDiscount.Text = "Discount Applied";
                    btnDiscount.Enabled = false;
                    break;
                case false:
                    MessageBox.Show("Order must exceed $5000 to be eligable for discount", "Cannot Apply Discount");
                    break;
            }
        }
    } // end of class main
}   



