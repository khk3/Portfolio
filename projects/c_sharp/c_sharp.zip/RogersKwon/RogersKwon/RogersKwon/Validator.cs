﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogersKwon
{
    public static class Validator
    {
        private static string title = "Entry Error";
        public static string Title { get; set; }
        public static bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", title);
                textBox.Focus();
                return false;
            }
            return true;
        }//end of IsPresent

        public static bool IsInt32(TextBox textBox)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Title);
                textBox.Focus();
                return false;
            }

        }//validates if user inputed an Int

        public static bool IsDecimal(TextBox textBox)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }// end of isDecimal

        public static bool IsDouble(TextBox textBox)
        {
            double number = 0;
            if (Double.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show("Screen Size must be a double.", Title);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }//end of IsDouble

        public static bool IsBool (TextBox textBox)
        {
            bool result = false ;
            if(bool.TryParse(textBox.Text, out result) == true) 
            {
                result = true ;
                
               
            }
            if (result == false)
            {
                MessageBox.Show("All-in-One only accepts 'true' or 'false'", Title);
                textBox.Clear();
                textBox.Focus();
                result=false;

            }
            return result;
            
        }//End of IsBool

        public static bool NoCodeRepeat(List <Computer> computers, int code)
        {
            bool isInUse = false;

            foreach(Computer item in computers)
            {
                if (item.Code == code)
                {
                    isInUse = true;
                    break;
                }
            }

            return isInUse;
        }


    }//end of class Validator
}
