﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogersKwon
{
    //Written by Noah and Kang
    public partial class Captcha : Form
    {
        //Written by Noah
        //Sets tag to incorrect and calls CreateCaptcha
        public Captcha()
        {
            InitializeComponent();
            this.Tag = "incorrect";
            CreateCaptcha();
        }

        //Written by Kang
        //Method: CreateCaptcha()
        //Sent: Nothing
        //Returned: Nothing
        //Description: Creates a 4 digit int and sets it to the lblRandom
        private void CreateCaptcha()
        {
            Random rand = new Random();
            int randNum = rand.Next(1000, 9999);
            lblRandom.Text = randNum.ToString();
            txtRandom.Focus();
        }

        //Written by Kang
        //Method: btnCaptcha Click Event
        //Sent: Nothing
        //Returned: Nothing
        //Description: Validates if the captcha matches user input and sets the form tag to 'correct' then closes, otherwise displays an errror message
        private void btnCaptcha_Click(object sender, EventArgs e)
        {
            string randNum = lblRandom.Text;
            string userKey = txtRandom.Text;

            if (randNum == userKey)
            {
                this.Tag = "correct";
                this.Close();
            }
            else if (randNum != userKey)
            {
                MessageBox.Show("Didnt match");
                txtRandom.SelectAll();
            }
        }

        //Written by Noah
        //Method: btnNewCaptcha Click Event
        //Sent: Nothing
        //Returned: Nothing
        //Description: Allows the user to get a new random number and simply calls the CreateCaptcha Event
        private void btnNewCaptcha_Click(object sender, EventArgs e)
        {
            CreateCaptcha();
        }
    }
}
