﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RogersKwon
{
    public abstract class Products
    {
        
        public int Code, InStock, Ram;
        public string Brand, Model, Processor;
        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = (value < 500m) ? 500m : value; } // set validation
        }

        public Products() { }

        public Products(int code, int instock, int ram, string brand, string model, string processor, decimal price) 
        {
            Code = code;
            InStock = instock;
            Brand = brand;
            Model = model;
            Processor = processor;
            Price = price;
            Ram = ram;
        }

    } // End of Class Products

    public class Computer : Products, ICloneable
    {

        public int Ordered;
        public Products Info; // aggregation 

        public Computer() { }

        public Computer(Products info, int removed) 
        {
            Info = info;
            Ordered = removed;
        }

        public object Clone() //implementation interface IClonable
        {
            Computer c = new Computer();
                c.Code = this.Code;
                c.InStock = this.InStock;
                c.Brand = this.Brand;
                c.Model = this.Model;
                c.Processor = this.Processor;
                c.Price = this.Price;
                c.Ram = this.Ram;   
            return c;
        }

        ////overload relation operator
        /////compares Code,Brand,Model,Processor,Ram between 2 products.
        public static bool operator == (Computer c1, Computer c2)
        {
            bool result = false;
            bool codeMatch;
            codeMatch = c1.Code == c2.Code;

            bool brandMatch;
            brandMatch= c1.Brand == c2.Brand;

            bool modelMatch;
            modelMatch = c1.Model == c2.Model;

            bool processorMatch;
            processorMatch = c1.Processor == c2.Processor;

            bool ramMatch;
            ramMatch = c1.Ram == c2.Ram;

            if (c1.Equals(c2)&& codeMatch && brandMatch && modelMatch && processorMatch && ramMatch)
                result = true;
            return result;
            
        }
        public static int operator + (Computer c1, Computer c2) //overload mathematical operator
        {
            c1.InStock += c2.InStock;
            return c1.InStock;
        }

        //overload relation operator
        public static bool operator != (Computer c1, Computer c2)
        {
            return !(c1==c2);
        }
        
        //Verify if 2 Products have the same type
        public override bool Equals(object obj)
        {
            bool match = false;
            if (obj != null)
            {
                if (obj.GetType() == this.GetType())
                    match = true;
                else
                    match = false;
            }
            return match;
            
        }

        public override int GetHashCode()
        {
            string hashString = this.Info.Code + this.Info.Brand + this.Info.Model + this.Info.InStock + 
                this.Processor+this.Ram+this.Price;
            return hashString.GetHashCode();
        }




    } // End of Class Computer

    public sealed class Desktop : Computer
    {
        public bool AllInOne;
        public string Graphic;

        public Desktop() { }
        public Desktop(Products info, int ram, bool allInOne, string graphic) :base(info, ram)
        {
            Info = info;
            Ram = ram;
            AllInOne = allInOne;
            Graphic = graphic;
        }
        public override string ToString() => String.Format(
            "{0,-10}\n{1,-25}\n{2,10}\n{3,16}\n{4,-20}\n{5,-20}", "Brand: " + Brand, "Model: " + Model, "AllInOne: " + (AllInOne ? "Yes" : "No"), "Processor: " + Processor, "Ram: " + Ram, "Price: " + Price.ToString("C2"));

    } // End of Class Desktop

    public sealed class Laptop : Computer
    { 
        
        public double ScreenSize;
        public int Battery;

        public Laptop():base() { }
        public Laptop(Products info,int ram, double screenSize, int battery) : base(info, ram)
        {
            Info = info;
            Ram = ram;
            ScreenSize = screenSize;
            Battery = battery;  
        }

        public override string ToString() => String.Format(
            "{0,-30}\n{1,-30}\n{2,-30}\n{3,-30}\n{4,-30}\n{5,-20}", "Brand: " + Brand, "Model: " + Model, "Screen Size:" + ScreenSize, "Processor: " + Processor, "Ram: " + Ram, "Price: " + Price.ToString("C2"));
    } // End of Class Laptop


    

}
