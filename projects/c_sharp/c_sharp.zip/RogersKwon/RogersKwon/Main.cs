﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace RogersKwon
{
    public partial class Main : Form
    {
        private List<Computer> computers = new List<Computer>();

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            try
            {
                //Call ReadFile static class to get the products
                List<Desktop> desktopFile = ReadFile.GetDesktops(@"C:\files\desktops.xml");
                List<Laptop> laptopFile = ReadFile.GetLaptops(@"C:\files\laptops.xml");

                //Add the items from ProductsFile to the list
                computers.AddRange(desktopFile);
                computers.AddRange(laptopFile);

                //Call the DispalyProduct method
                DisplayProduct();
            }
            catch
            {
                MessageBox.Show("There are no products Available", "Error");
            }
        }

        //list of computers ( desktops and laptops)
        //List<Desktop> desktops = new List<Desktop>();
        // List<Laptop> laptops = new List<Laptop>();
        private void DisplayProduct()
        {
            int[] quantity = new int[10];
            for (int i = 0; i < quantity.Length; i++)
            {
                //lstQuantity.Items.Add(i + 1);
            }

            // Add computers to list of items
            foreach (Computer computer in computers)
            {                    
                lstProducts.Items.Add(computer.ToString());
            }

        }

        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstProducts.SelectedIndex;

            cboStock.Items.Clear();
            int available = computers[index].InStock;
            for(int i = 0; i < available; i++)
            {
                cboStock.Items.Add(i+1);
            }
            if (cboStock.Items.Count < 1)
                cboStock.Enabled = false;
            else
                cboStock.Enabled = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int index = lstProducts.SelectedIndex;
            int select = Convert.ToInt32(cboStock.SelectedIndex + 1);

            if (index != -1)
            {
                if (computers[index].InStock >= select)
                {
                    // add the products to order listbox
                    lstOrder.Items.Add(
                        String.Format("{0,-10}{1,-20}{2,-2}", computers[index].Brand, computers[index].Model, select));

                    // set new instock
                    computers[index].InStock -= select;
                    lstProducts.Items.Clear();
                    DisplayProduct();
                    lstProducts.SelectedIndex = index;
                }
                else
                {
                    MessageBox.Show("There is no Stock available", "No Stock");
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            // get a collection of inddices for orders
            ListBox.SelectedIndexCollection highlighted = lstOrder.SelectedIndices;

            // remove item at each index selected
            for(int i = highlighted.Count - 1; i >= 0; i--)
            {
                lstOrder.Items.RemoveAt(highlighted[i]);
            }

        }

        private void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            DialogResult action = MessageBox.Show("Would you like to place this order?", "Confirm", MessageBoxButtons.YesNo);
            switch (action)
            {
                case DialogResult.Yes:
                    break;
                case DialogResult.No:
                    break;

            }
        }
    } // end of class main
        
}


