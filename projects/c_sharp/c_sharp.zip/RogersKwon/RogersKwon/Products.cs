﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RogersKwon

{   //Written by Noah and Kang
    public abstract class Products
    {
        // Property declaration for Products class
        public int Code, InStock, Ram;
        public string Brand, Model, Processor;
        private decimal price;

        // Set for Price. Price for an item cannot be below $500
        public decimal Price
        {
            get { return price; }
            set { price = (value < 500m) ? 500m : value; } // set validation
        }

        //Default constructor - does nothing
        public Products() { }

        //Custom constructor - sets properties
        public Products(int code, int instock, int ram, string brand, string model, string processor, decimal price) 
        {
            Code = code;
            InStock = instock;
            Brand = brand;
            Model = model;
            Processor = processor;
            Price = price;
            Ram = ram;
        }

    } // End of Class Products

    //Written by Noah and Kang
    public class Computer : Products, ICloneable
    {
        //new property - ordered
        public int Ordered;
        // aggregation 
        public Products Info;

        //Default constructor - does nothing
        public Computer() { }

        //Custom constructor - sets properties
        public Computer(Products info, int removed) 
        {
            Info = info;
            Ordered = removed;
        }

        //Written by Noah
        //Method: Clone() for IClonable
        //Sent: Nothing
        //Returned: Object
        //Description: Used to Clone an item to be added to the Cart
        public object Clone() //implementation interface IClonable
        {
            Computer c = new Computer();
                c.Code = this.Code;
                c.InStock = this.InStock;
                c.Brand = this.Brand;
                c.Model = this.Model;
                c.Processor = this.Processor;
                c.Price = this.Price;
                c.Ram = this.Ram;   
            return c;
        }

        //Written by Kang
        //overload operator ==
        //Sent: 2 computer Objects
        //Returned: Bool
        //Description: Verifies if 2 computers sent are a match
        public static bool operator == (Computer c1, Computer c2)
        {
            bool result = false;
            bool codeMatch;
            codeMatch = c1.Code == c2.Code;

            bool brandMatch;
            brandMatch= c1.Brand == c2.Brand;

            bool modelMatch;
            modelMatch = c1.Model == c2.Model;

            bool processorMatch;
            processorMatch = c1.Processor == c2.Processor;

            bool ramMatch;
            ramMatch = c1.Ram == c2.Ram;

            if (c1.Equals(c2)&& codeMatch && brandMatch && modelMatch && processorMatch && ramMatch)
                result = true;
            return result;
            
        }

        //Written by Kang
        //overload operator +
        //Sent: 2 computer Objects
        //Returned: Int
        //Description: Adds the Instock from computer c2 to c1 returns c1.Instock
        public static int operator + (Computer c1, Computer c2) //overload mathematical operator
        {
            c1.InStock += c2.InStock;
            return c1.InStock;
        }

        //Written by Kang
        //overload operator !-
        //Sent: 2 computer Objects
        //Returned: bool
        //Description: returns opposit of == overloaded operator
        public static bool operator != (Computer c1, Computer c2)
        {
            return !(c1==c2);
        }

        //Written by Kang
        //overload Method Equals()
        //Sent: nothing
        //Returned: bool
        //Description: Verify if 2 Products have the same type
        public override bool Equals(object obj)
        {
            bool match = false;
            if (obj != null)
            {
                if (obj.GetType() == this.GetType())
                    match = true;
                else
                    match = false;
            }
            return match;
            
        }

        //Written by Kang
        //overload Method GetHashCode()
        //Sent: nothing
        //Returned: int
        //Description: returns hashCode
        public override int GetHashCode()
        {
            string hashString = this.Info.Code + this.Info.Brand + this.Info.Model + this.Info.InStock + 
                this.Processor+this.Ram+this.Price;
            return hashString.GetHashCode();
        }

    } // End of Class Computer

    //Written by Noah and Kang
    public sealed class Desktop : Computer
    {
        //Properties
        public bool AllInOne;
        public string Graphic;

        //Default Constructor - does nothing
        public Desktop() { }
        //Custom Constructor - Sets properties
        public Desktop(Products info, int ram, bool allInOne, string graphic) :base(info, ram)
        {
            Info = info;
            Ram = ram;
            AllInOne = allInOne;
            Graphic = graphic;
        }

        //Written by Noah
        //overload Method ToString()
        //Sent: nothing
        //Returned: string
        //Description: override ToString() for Desktop class, Writes product Information to be Displayed to the Label
        public override string ToString() => String.Format(
            "{0,-10}\n{1,-25}\n{2,10}\n{3,16}\n{4,-20}\n{5,-20}", "Brand: " + Brand, "Model: " + Model, "AllInOne: " + (AllInOne ? "Yes" : "No"), "Processor: " + Processor, "Ram: " + Ram, "Price: " + Price.ToString("C2"));

    } // End of Class Desktop


    public sealed class Laptop : Computer
    {
        //Properties
        public double ScreenSize;
        public double Battery;

        //Default Constructor - does nothing
        public Laptop():base() { }

        //Custom Constructor - Sets properties
        public Laptop(Products info,int ram, double screenSize, int battery) : base(info, ram)
        {
            Info = info;
            Ram = ram;
            ScreenSize = screenSize;
            Battery = battery;  
        }

        //Written by Noah
        //overload Method ToString()
        //Sent: nothing
        //Returned: string
        //Description: override ToString() for Lapktop class, Writes product Information to be Displayed to the Label
        public override string ToString() => String.Format(
            "{0,-30}\n{1,-30}\n{2,-30}\n{3,-30}\n{4,-30}\n{5,-20}", "Brand: " + Brand, "Model: " + Model, "Screen Size:" + ScreenSize, "Processor: " + Processor, "Ram: " + Ram, "Price: " + Price.ToString("C2"));
    } // End of Class Laptop


    

}
