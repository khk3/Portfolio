﻿namespace RogersKwon
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblStock = new System.Windows.Forms.Label();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cboQuantity = new System.Windows.Forms.ComboBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lstOrder = new System.Windows.Forms.ListBox();
            this.tabComputers = new System.Windows.Forms.TabControl();
            this.tabDesktops = new System.Windows.Forms.TabPage();
            this.lstDesktops = new System.Windows.Forms.ListBox();
            this.tabLaptops = new System.Windows.Forms.TabPage();
            this.lstLaptops = new System.Windows.Forms.ListBox();
            this.lblTotalDisplay = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblMembership = new System.Windows.Forms.Label();
            this.btnDiscount = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.sfdConfirm = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.tabComputers.SuspendLayout();
            this.tabDesktops.SuspendLayout();
            this.tabLaptops.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.Location = new System.Drawing.Point(842, 518);
            this.btnConfirmOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(84, 45);
            this.btnConfirmOrder.TabIndex = 4;
            this.btnConfirmOrder.Text = "Confirm";
            this.btnConfirmOrder.UseVisualStyleBackColor = true;
            this.btnConfirmOrder.Click += new System.EventHandler(this.btnConfirmOrder_Click_1);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(697, 518);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(84, 45);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(552, 518);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(84, 45);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblStock);
            this.groupBox1.Controls.Add(this.lblAvailable);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.cboQuantity);
            this.groupBox1.Controls.Add(this.lblProduct);
            this.groupBox1.Location = new System.Drawing.Point(552, 120);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(374, 383);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // lblStock
            // 
            this.lblStock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStock.Location = new System.Drawing.Point(127, 331);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(180, 20);
            this.lblStock.TabIndex = 36;
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.Location = new System.Drawing.Point(51, 331);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(56, 17);
            this.lblAvailable.TabIndex = 35;
            this.lblAvailable.Text = "Stock:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(35, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 17);
            this.label19.TabIndex = 29;
            this.label19.Text = "Quantity";
            // 
            // cboQuantity
            // 
            this.cboQuantity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQuantity.FormattingEnabled = true;
            this.cboQuantity.Location = new System.Drawing.Point(127, 26);
            this.cboQuantity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboQuantity.Name = "cboQuantity";
            this.cboQuantity.Size = new System.Drawing.Size(194, 25);
            this.cboQuantity.TabIndex = 32;
            // 
            // lblProduct
            // 
            this.lblProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProduct.Location = new System.Drawing.Point(9, 85);
            this.lblProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(354, 284);
            this.lblProduct.TabIndex = 31;
            // 
            // lstOrder
            // 
            this.lstOrder.FormattingEnabled = true;
            this.lstOrder.ItemHeight = 17;
            this.lstOrder.Location = new System.Drawing.Point(945, 127);
            this.lstOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstOrder.Name = "lstOrder";
            this.lstOrder.Size = new System.Drawing.Size(417, 344);
            this.lstOrder.TabIndex = 11;
            // 
            // tabComputers
            // 
            this.tabComputers.Controls.Add(this.tabDesktops);
            this.tabComputers.Controls.Add(this.tabLaptops);
            this.tabComputers.Location = new System.Drawing.Point(17, 100);
            this.tabComputers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabComputers.Name = "tabComputers";
            this.tabComputers.SelectedIndex = 0;
            this.tabComputers.Size = new System.Drawing.Size(520, 480);
            this.tabComputers.TabIndex = 37;
            this.tabComputers.SelectedIndexChanged += new System.EventHandler(this.tabComputers_SelectedIndexChanged);
            // 
            // tabDesktops
            // 
            this.tabDesktops.Controls.Add(this.lstDesktops);
            this.tabDesktops.Location = new System.Drawing.Point(4, 26);
            this.tabDesktops.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabDesktops.Name = "tabDesktops";
            this.tabDesktops.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabDesktops.Size = new System.Drawing.Size(512, 450);
            this.tabDesktops.TabIndex = 0;
            this.tabDesktops.Text = "Desktops";
            this.tabDesktops.UseVisualStyleBackColor = true;
            // 
            // lstDesktops
            // 
            this.lstDesktops.FormattingEnabled = true;
            this.lstDesktops.ItemHeight = 17;
            this.lstDesktops.Location = new System.Drawing.Point(26, 20);
            this.lstDesktops.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lstDesktops.Name = "lstDesktops";
            this.lstDesktops.Size = new System.Drawing.Size(460, 412);
            this.lstDesktops.TabIndex = 1;
            this.lstDesktops.SelectedIndexChanged += new System.EventHandler(this.lstDesktops_SelectedIndexChanged_1);
            // 
            // tabLaptops
            // 
            this.tabLaptops.Controls.Add(this.lstLaptops);
            this.tabLaptops.Location = new System.Drawing.Point(4, 26);
            this.tabLaptops.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabLaptops.Name = "tabLaptops";
            this.tabLaptops.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabLaptops.Size = new System.Drawing.Size(512, 450);
            this.tabLaptops.TabIndex = 1;
            this.tabLaptops.Text = "Laptops";
            this.tabLaptops.UseVisualStyleBackColor = true;
            // 
            // lstLaptops
            // 
            this.lstLaptops.FormattingEnabled = true;
            this.lstLaptops.ItemHeight = 17;
            this.lstLaptops.Location = new System.Drawing.Point(26, 20);
            this.lstLaptops.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lstLaptops.Name = "lstLaptops";
            this.lstLaptops.Size = new System.Drawing.Size(460, 412);
            this.lstLaptops.TabIndex = 0;
            this.lstLaptops.SelectedIndexChanged += new System.EventHandler(this.lstLaptops_SelectedIndexChanged);
            // 
            // lblTotalDisplay
            // 
            this.lblTotalDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalDisplay.Location = new System.Drawing.Point(1131, 552);
            this.lblTotalDisplay.Name = "lblTotalDisplay";
            this.lblTotalDisplay.Size = new System.Drawing.Size(215, 20);
            this.lblTotalDisplay.TabIndex = 39;
            // 
            // lblCustomer
            // 
            this.lblCustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustomer.Location = new System.Drawing.Point(56, 42);
            this.lblCustomer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(324, 35);
            this.lblCustomer.TabIndex = 40;
            this.lblCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMembership
            // 
            this.lblMembership.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblMembership.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMembership.ForeColor = System.Drawing.Color.Yellow;
            this.lblMembership.Location = new System.Drawing.Point(558, 43);
            this.lblMembership.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMembership.Name = "lblMembership";
            this.lblMembership.Size = new System.Drawing.Size(170, 35);
            this.lblMembership.TabIndex = 41;
            this.lblMembership.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDiscount
            // 
            this.btnDiscount.Location = new System.Drawing.Point(1131, 491);
            this.btnDiscount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDiscount.Name = "btnDiscount";
            this.btnDiscount.Size = new System.Drawing.Size(154, 35);
            this.btnDiscount.TabIndex = 42;
            this.btnDiscount.Text = "Apply Discount";
            this.btnDiscount.UseVisualStyleBackColor = true;
            this.btnDiscount.Click += new System.EventHandler(this.btnDiscount_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(1026, 553);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(56, 17);
            this.lblTotal.TabIndex = 43;
            this.lblTotal.Text = "Total:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::RogersKwon.Properties.Resources._699234;
            this.pictureBox3.Location = new System.Drawing.Point(1274, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 44;
            this.pictureBox3.TabStop = false;
            // 
            // sfdConfirm
            // 
            this.sfdConfirm.FileName = "OrdersFor";
            this.sfdConfirm.InitialDirectory = "c:\\files";
            this.sfdConfirm.Title = "File Save";
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 679);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnDiscount);
            this.Controls.Add(this.lblMembership);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblTotalDisplay);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnConfirmOrder);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lstOrder);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.tabComputers);
            this.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CustomerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CustomerFormRogersKwon";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabComputers.ResumeLayout(false);
            this.tabDesktops.ResumeLayout(false);
            this.tabLaptops.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.ListBox lstOrder;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ComboBox cboQuantity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.TabControl tabComputers;
        private System.Windows.Forms.TabPage tabDesktops;
        private System.Windows.Forms.TabPage tabLaptops;
        private System.Windows.Forms.ListBox lstDesktops;
        private System.Windows.Forms.ListBox lstLaptops;
        private System.Windows.Forms.Label lblTotalDisplay;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblMembership;
        private System.Windows.Forms.Button btnDiscount;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.SaveFileDialog sfdConfirm;
    }
}