﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogersKwon
{
    //Written by Noah and Kang
    public static class Validator
    {
        private static string title = "Entry Error";
        public static string Title { get; set; }

        //Written by Kang
        //Method: IsPresnt()
        //Sent: Textbox
        //Returned: Bool
        //Description: Validates that Textboxes are not empty. Sets Textbox tag if empty
        public static bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", title);
                textBox.Focus();
                return false;
            }
            return true;
        }//end of IsPresent

        //Written by Kang
        //Method: IsInt32()
        //Sent: Textbox
        //Returned: Bool
        //Description: Validates that Textboxes data Is an Integer. Sets tag if is not an integer
        public static bool IsInt32(TextBox textBox)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Title);
                textBox.Focus();
                return false;
            }

        }//validates if user inputed an Int

        //Written by Kang
        //Method: IsDecimal()
        //Sent: Textbox
        //Returned: Bool
        //Description: Validates that Textboxes data Is a Decimal. Sets tag if is not an Decimal
        public static bool IsDecimal(TextBox textBox)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }// end of isDecimal

        //Written by Kang
        //Method: IsDouble()
        //Sent: Textbox
        //Returned: Bool
        //Description: Validates that Textboxes data Is a Double. Sets tag if is not a Double
        public static bool IsDouble(TextBox textBox)
        {
            double number = 0;
            if (Double.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show("Screen Size must be a double.", Title);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }//end of IsDouble

        //Written by Kang
        //Method: IsBool()
        //Sent: Textbox
        //Returned: Bool
        //Description: Validates that Textboxes data Is an Boolean. Sets tag if is not an Bool
        public static bool IsBool (TextBox textBox)
        {
            bool result = false ;
            if(bool.TryParse(textBox.Text, out result) == true) 
            {
                result = true ;
                
               
            }
            if (result == false)
            {
                MessageBox.Show("All-in-One only accepts 'true' or 'false'", Title);
                textBox.Clear();
                textBox.Focus();
                result=false;

            }
            return result;
            
        }//End of IsBool

        //Written by Noah
        //Method: NoCodeRepeated()
        //Sent: List <computer>, int code
        //Returned: Bool
        //Description: Loops through list sent, determines if the code matches and returns bool stating if code is already in use
        public static bool NoCodeRepeat(List <Computer> computers, int code)
        {
            bool isInUse = false;

            foreach(Computer item in computers)
            {
                if (item.Code == code)
                {
                    isInUse = true;
                    break;
                }
            }

            return isInUse;
        }


    }//end of class Validator
}
