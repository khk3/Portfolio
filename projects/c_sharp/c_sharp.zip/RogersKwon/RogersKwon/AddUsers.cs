﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace RogersKwon
{
    public class AddUsers
    {
        public static List<Users> GetUsers()
        {
            List<Users> users = new List<Users>();

            string path = @"c:\files\users.xml";
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            XmlReader xmlInUsers = XmlReader.Create(path, settings);

            if (xmlInUsers.ReadToDescendant("record"))
            {
                do
                {
                    xmlInUsers.ReadStartElement("record");
                    
                    
                    string firstName = xmlInUsers.ReadElementContentAsString();
                    string lastName = xmlInUsers.ReadElementContentAsString();
                    string login = xmlInUsers.ReadElementContentAsString();
                    string password = xmlInUsers.ReadElementContentAsString();
                    bool access = xmlInUsers.ReadElementContentAsBoolean();
                    

                    Users user = new Users(lastName, firstName, login, password, access);
                    //store desktop into desktops List
                    users.Add(user);
                }
                while (xmlInUsers.ReadToNextSibling("record"));

            }//end if
            xmlInUsers.Close();
            return users;
        }

    }
}
