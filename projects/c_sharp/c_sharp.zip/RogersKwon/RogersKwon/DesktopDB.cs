﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RogersKwon
{
    public static class DesktopDB
    {
        public static List<Desktop> GetDesktops()
        { 
            List<Desktop> desktops = new List<Desktop>();

            string path = @"c:\files\computers.xml";
            //string path = @"c:\files\computers.xml";
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;

            // create the XmlReader object
            XmlReader xmlInDesktops = XmlReader.Create(path, settings);
  
            if (xmlInDesktops.ReadToDescendant("Desktop"))
            {
                do
                {
                    xmlInDesktops.ReadStartElement("Desktop");
                    Products infoDesktop = new Products();

                    infoDesktop.Code = xmlInDesktops.ReadElementContentAsInt();
                    infoDesktop.InStock = xmlInDesktops.ReadElementContentAsInt();
                    infoDesktop.Brand = xmlInDesktops.ReadElementContentAsString();
                    infoDesktop.Model = xmlInDesktops.ReadElementContentAsString();
                    infoDesktop.Processor = xmlInDesktops.ReadElementContentAsString();
                    infoDesktop.Price = xmlInDesktops.ReadElementContentAsDecimal();

                    int ram = xmlInDesktops.ReadElementContentAsInt();
                    string allInOne = xmlInDesktops.ReadElementContentAsString();
                    string graphic = xmlInDesktops.ReadElementContentAsString();

                    Desktop desktop = new Desktop(infoDesktop, ram, allInOne, graphic);
                    //store desktop into desktops List
                    desktops.Add(desktop);
                }
                while (xmlInDesktops.ReadToNextSibling("Desktop"));

            }//end if
            xmlInDesktops.Close();
            return desktops;
          
            
       
        }
        
    }
}
