﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace RogersKwon
{
    public partial class CustomerForm : Form
    {
        // user sent from login form
        public Users customer;

        // List of Products
        public List<Desktop> desktops = new List<Desktop>();      
        public List<Laptop> laptops = new List<Laptop>();

        // List of all the customers orders
        public List<Computer> cart = new List<Computer>();

        //Written by Noah
        //Method: CustomerForm
        //Sent: Customer
        //Returned: Nothing
        //Description: Initialize, set class level user to user sent, read items from file, call DisplayProduct()
        public CustomerForm(Customer user)
        {
            InitializeComponent();

            customer = user;
            lblCustomer.Text = "Welcome, " + user.FirstName;
            lblMembership.Text = user.LoyaltyMember ? "Loyalty Member" : HideMembership();

            // attempt to read from files
            desktops = CompanyDB.GetDesktops();
            laptops = CompanyDB.GetLaptops();

            //Display the Products in listboxs
            DisplayProduct();

            //set savefiledialog FileName
            sfdConfirm.FileName += customer.FirstName + ".txt";
        }

        //Written by Noah
        //Method: HideMembership()
        //Sent: Nothing
        //Returned: String
        //Description: Called from the ternary operator, Hides the Membership label if the customer is not one, returns empty string
        private string HideMembership()
        {
            lblMembership.Hide();
            btnDiscount.Hide();
            return "";
        }

        //Written by Noah
        //Method: DisplayProduct()
        //Sent: Nothing
        //Returned: Nothing
        //Description: When called, Refreshes both listboxes. Clears all products and re-adds items to both lists
        private void DisplayProduct()
        {
            // Clear both listboxes if item was added
            lstDesktops.Items.Clear();
            lstLaptops.Items.Clear();

            // Add computers to list of items
           foreach(Desktop desktop in desktops)
            {
                lstDesktops.Items.Add(String.Format(
                    "{0,-15}{1,-20}{2,-18}{3,-20}{4,-15}", "(" + desktop.GetType().Name + ")", desktop.Brand, desktop.Model, desktop.InStock, desktop.Price.ToString("C2")));
            }
            foreach (
                Laptop laptop in laptops)
            
            {
                lstLaptops.Items.Add(String.Format(
                    "{0,-15}{1,-20}{2,-18}{3,-20}{4,-15}", "(" + laptop.GetType().Name + ")", laptop.Brand, laptop.Model, laptop.InStock, laptop.Price.ToString("C2")));
            }

        }

        //Written by Noah
        //Method: QuantityDisplay()
        //Sent: int 'available'
        //Returned: Nothing
        //Description: takes in an int of the quantity available for a selected item. Populates the combox according to value sent. Disabled on no stock
        private void QuantityDisplay(int available)
        {
            //array of max quantyty available to order
           
            //Clear quantity Combobox
            cboQuantity.Items.Clear();

            switch (available < 1)
            {
                // if there is no stock, disbale quantity combobox
                case true:
                    cboQuantity.Enabled = false;
                    break;
                // if there is stock for selected item, enable and populate combobox, select quantity '1'
                case false:
                    cboQuantity.Enabled = true;

                    //array will be created with the size of the product amount  KK
                    int[] qntAvailable = new int[available];  
                    
                    for (int i = 0; i < qntAvailable.Length; i++)
                    {                       
                        cboQuantity.Items.Add(i + 1);
                    }                                 
                    /*
                    for (int i = 0; i < available; i++)
                    {
                        cboQuantity.Items.Add(i + 1);
                    }
                    cboQuantity.SelectedIndex = 0;
                    */
                    break;
            }
        }

        //Written by Noah and Kang
        //lstDesktops indexchanged Event
        //Returned: Nothing
        //Description: takes in an int of the quantity available for a selected item. Populates the combox according to value sent. Disabled on no stock
        private void lstDesktops_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            // shorthand for index, declare availability
            int index = lstDesktops.SelectedIndex;
            int available = 0;

            
            if (index != -1) 
            {
                // Update Label, set availability, must check if index is not -1
                lblProduct.Text = desktops[index].ToString();
                available = desktops[index].InStock;

                // update stock label
                lblStock.Text = desktops[index].InStock < 1 ? "Currently Unavailable" : desktops[index].InStock.ToString();
                // call Display method for Quantity
                QuantityDisplay(available);
            }
        }

        //Written by Noah and Kang
        //lstLaptops indexchanged Event
        //Returned: Nothing
        //Description: takes in an int of the quantity available for a selected item. Populates the combox according to value sent. Disabled on no stock
        private void lstLaptops_SelectedIndexChanged(object sender, EventArgs e)
        {
            // shorthand variables
            int index = lstLaptops.SelectedIndex;
            int available = 0;

            if (index != -1)
            {
                lblProduct.Text = laptops[index].ToString();
                available = laptops[index].InStock;

                // update stock label
                lblStock.Text = laptops[index].InStock < 1 ? "Currently Unavailable" : laptops[index].InStock.ToString();
                // call Display method for Quantity
                QuantityDisplay(available);
            }
        }

        //Written by Noah and Kang
        //add button click Event
        //Returned: Nothing
        //Description: determines which list and index is being selected. decreases stock from correct item, creates a deep clone of the product
        //and sets Ordered property to amount ordered. Then refreshes all lists, clears combobox
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int indexD = lstDesktops.SelectedIndex;
            int indexL = lstLaptops.SelectedIndex;
            int quantity = Convert.ToInt32(cboQuantity.SelectedIndex + 1);
            lblStock.Text = "";

            // if item is selected in desktop listbox
            if (indexD != -1)
            {
                // if the instock amount is greater than quantity selected
                if (desktops[indexD].InStock >= quantity && cboQuantity.SelectedIndex != -1)
                {
                    // decrease item InStock
                    desktops[indexD].InStock -= quantity;

                    Computer clone = (Computer)desktops[indexD].Clone();
                    bool isEqual = false;

                    foreach(Computer c in cart)
                    {
                        if (clone == c)
                        {
                            c.Ordered += quantity;
                            isEqual = true;
                        }
                    }
                    if (isEqual == false)
                    {
                        clone.Ordered = quantity;
                        cart.Add(clone);
                    }

                }
                else if (desktops[indexD].InStock==0)
                {
                    MessageBox.Show("There is no Stock available", "No Stock");
                    
                }
            }
            // or if a laptop item is selected 

            else if (indexL != -1)
            {
                // if the instock amount is greater than quantity selected
                if (laptops[indexL].InStock >= quantity && cboQuantity.SelectedIndex != -1)
                {
                    // decrease item InStock
                    laptops[indexL].InStock -= quantity;

                    // construct a new Computer (custom constructor), add to orders
                    Computer clone = (Computer)laptops[indexL].Clone();
                    bool isEqual = false;

                    foreach (Computer c in cart)
                    {
                        if (clone == c)
                        {
                            c.Ordered += quantity;
                            isEqual = true;
                        }
                    }
                    if (isEqual == false)
                    {
                        clone.Ordered = quantity;
                        cart.Add(clone);
                    }
                }
                else if(laptops[indexD].InStock == 0)
                {
                    MessageBox.Show("There is no Stock available", "No Stock");

                }
            }

            // refresh lits to show decrease in stock and order added
            DisplayProduct();
            UpdateCart();
            cboQuantity.Items.Clear(); 
        }

        //Written by Noah
        //Method: UpdateCart()
        //Sent: Nothing
        //Returned: Nothing
        //Description: Clears the lstOrders and rewrites to it with the updated list of items in cart
        //Calculates and displays total, re-enables the discount button
        private void UpdateCart()
        {
            // Clear cart and reset label
            lstOrder.Items.Clear();
            // total variable
            decimal total = 0m;
            // Then update
            foreach(Computer computer in cart)
            {
                // Display product
                lstOrder.Items.Add(String.Format(
                    "{0,-10}{1,-8}{2,-10}{3,15}", "x" + computer.Ordered, computer.Brand, computer.Model, (computer.Ordered * computer.Price).ToString("C2")));
                // Total updated
                total += (computer.Ordered * computer.Price);
            }
            // add total to label
            lblTotalDisplay.Text = total.ToString("N2");
            // renable discount if change is made to cart
            btnDiscount.Enabled = true;
        }

        //Written by Noah
        //remove button click event
        //Returned: Nothing
        //Description: Removes item from orders list where user has selected, loops through all items
        //when a code match is found, the Instock propertry is reset (adds ordered property value back)
        private void btnRemove_Click(object sender, EventArgs e)
        {
            // index shorthand
            int index = lstOrder.SelectedIndex;

            // index must be selected in order to remove an item
            if (index != -1)
            {
                // get product of order item for removal and quantity that was ordered
                int code = cart[index].Code;
                int ordered = cart[index].Ordered;

                // Compare code against both Lists of products, add back stock to item if removed from the cart
                foreach (Desktop desktop in desktops)
                {
                    if (desktop.Code == code)
                    {
                        desktop.InStock += ordered;
                    }
                }
                foreach (Laptop laptop in laptops)
                {
                    if (laptop.Code == code)
                    {
                        laptop.InStock += ordered;
                    }
                }

                // remove cart List
                cart.RemoveAt(index);
              
            }
            DisplayProduct();
            UpdateCart();
        }

        //Written by Noah and Kang
        //confirm button click event
        //Returned: Nothing
        //Description: Writes the users order to a text file, user has chance to back out and return to form
        //if they proceed, the file is written, cart is emptied and lists are refreshed. Also rewrites xml files for products
        private void btnConfirmOrder_Click_1(object sender, EventArgs e)
        {
            if (lstOrder.Items.Count > 0)
            {
                DialogResult action = MessageBox.Show("Would you like to place this order?", "Confirm", MessageBoxButtons.YesNo);

                switch (action)
                {
                    case DialogResult.Yes:

                        SaveFileDialog userOrder = sfdConfirm;
                        userOrder.OverwritePrompt = false;

                        if (userOrder.ShowDialog() == DialogResult.Cancel)
                        {
                            MessageBox.Show("Must Select a file to save an order", "File Error");
                            return;
                        }
                        else
                        {
                            try
                            {
                                decimal total = 0m;

                                StreamWriter outputFile = new StreamWriter(sfdConfirm.FileName, true);
                                outputFile.WriteLine("================================================================");
                                outputFile.WriteLine(String.Format("{0,-20}{1,-20}", "First Name: " + customer.FirstName, "Last Name: " + customer.LastName + "\n"));

                                foreach (Computer item in cart)
                                {
                                    outputFile.WriteLine(String.Format("{0,-12}{1,-10}{2,-20}{3,-5}{4,-10}", "\t" + "ID." +
                                    item.Code, item.Brand, item.Model, "x." + item.Ordered, (item.Ordered * item.Price).ToString("C2")));
                                    total += (item.Price * item.Ordered);
                                }

                                if (btnDiscount.Text == "Discount Applied")
                                {
                                    outputFile.WriteLine("\n\t\t\t\t\tLoyalty Member discount applied, You saved " + (total * 0.1m).ToString("C2"));
                                    outputFile.WriteLine("\n\t\t\t\t\tTotal: $" + (total * 0.9m).ToString("C2") + "\n");
                                }
                                else
                                {
                                    outputFile.WriteLine("\n\t\t\t\t\tTotal: $" + total.ToString("C2") + "\n");
                                }

                                outputFile.Close();

                                // Clear the order, redisplay all lists
                                cart.Clear();
                                DisplayProduct();
                                UpdateCart();

                                CompanyDB.SaveLaptops(laptops);
                                CompanyDB.SaveDesktops(desktops);

                                MessageBox.Show("Your order has been placed", "Confirm");
                                lblTotalDisplay.Text = "";
                            }
                            catch
                            {
                                MessageBox.Show("An error occured", "Error");
                            }
                        }
                        break;
                    case DialogResult.No:
                        break;
                }
            }
            else
            {
                MessageBox.Show("There is no product in your cart", "Add product");
            }
        }

        //Written by Noah
        //tab index changed event
        //Returned: Nothing
        //Description: calls DisplayProduct and clears opposite list for current tab selected.
        //prevents user from selected multiple items at once
        private void tabComputers_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(tabComputers.SelectedIndex)
            {
                case 0:
                    DisplayProduct();
                    lstLaptops.Items.Clear();
                    break;
                case 1:
                    DisplayProduct();
                    lstDesktops.Items.Clear();
                    break;
            }
        }

        //Written by Noah
        //Form Closing Event
        //Returned: Nothing
        //Prompts the user if they have items in their cart. Items will not be saved.
        //user has chance to back out, otherwise customerForm is closed
        private void CustomerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(cart.Count > 0)
            {
                DialogResult formClose = MessageBox.Show("You currently have items saved to your cart.\n" +
                                                         "NK Computers cannot guarantee the availability of these items until a purchase has been made.\n" +
                                                         "These items will not be Saved.\n\n" +
                                                         "Are you sure you wish to Logout?", "Confirm Close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (formClose == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        //Written by Noah
        //Discount button click
        //Returned: Nothing
        //Available to loyalty members. User can apply a flat 10% discount if their orders exceeds $5000
        private void btnDiscount_Click(object sender, EventArgs e)
        {
            if(lblTotalDisplay.Text!= "")
            {
                double total = Convert.ToDouble(lblTotalDisplay.Text);
                switch (total > 5000.00)
                {
                    case true:
                        lblTotalDisplay.Text = (total * 0.9).ToString("C2");// 10% of discount applied
                        btnDiscount.Text = "Discount Applied";
                        btnDiscount.Enabled = false;
                        
                        break;
                    case false:
                        MessageBox.Show("Order must exceed $5000 to be eligable for discount", "Cannot Apply Discount");
                        break;
                }

            }
         
        }
    } // end of class main
}   



