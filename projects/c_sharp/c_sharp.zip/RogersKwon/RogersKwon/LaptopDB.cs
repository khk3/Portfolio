﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RogersKwon
{
    public static class LaptopDB
    {
        public static List<Laptop> GetLaptops()
        {
            
            List<Laptop> laptops = new List<Laptop>();

            string path = @"c:\files\computers.xml";
            //string path = @"c:\files\computers.xml";
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;

            // create the XmlReader object
            XmlReader xmlInLaptops = XmlReader.Create(path, settings);
            if (xmlInLaptops.ReadToDescendant("Laptop"))
            {
                // create one Product object for each Product node
                do
                {
                    xmlInLaptops.ReadStartElement("Laptop");
                    Products infoLaptop = new Products();

                    infoLaptop.Code = xmlInLaptops.ReadElementContentAsInt();
                    infoLaptop.InStock = xmlInLaptops.ReadElementContentAsInt();
                    infoLaptop.Brand = xmlInLaptops.ReadElementContentAsString();
                    infoLaptop.Model = xmlInLaptops.ReadElementContentAsString();
                    infoLaptop.Processor = xmlInLaptops.ReadElementContentAsString();
                    infoLaptop.Price = xmlInLaptops.ReadElementContentAsDecimal();

                    int ram = xmlInLaptops.ReadElementContentAsInt();
                    double screenSize = xmlInLaptops.ReadElementContentAsDouble();
                    int battery= xmlInLaptops.ReadElementContentAsInt();

                    Laptop laptop = new Laptop(infoLaptop, ram, screenSize, battery);
                    //store the laptop into laptops List
                    laptops.Add(laptop);
                }
                while (xmlInLaptops.ReadToNextSibling("Laptop"));
            }
            xmlInLaptops.Close();
            return laptops;
        }


    }//end of class LaptopDB
}
