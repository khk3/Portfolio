﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace RogersKwon
{
    public partial class LoginForm : Form
    {
        //Class level list declaration of users, no defined size
        private List<Users> users = new List<Users>();
        public LoginForm()
        {
            InitializeComponent();          
        }

        //Written by Noah
        //Form Load Event
        //Attempts to read users from file, adding to class level list 'users'. Displays Message if file not found
        private void Form1_Load(object sender, EventArgs e)
        {
            try
           {
                //Call ReadFile static class to get the users
                List<Users> userFile = CompanyDB.GetUsers(@"C:\files\users.xml");

                //Add the items from ProductsFile to the list
                users.AddRange(userFile);

                //focus Testbox
                txtLogin.Focus();
            }
            catch
            {
                MessageBox.Show("Connection Lost", "Error");               
                Close();
            }
        }

        //Written by Noah and Kang
        //Method: btnLogin Click Event
        //Sent: Nothing
        //Returned: Nothing
        //Description: uses Validator class to verify textboxes have data, loops through users to verify a login with correct credentials
        //Opens the captcha form. When the user completes the captcha correctly, uses access property to open admin or user form
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text;
            string password= txtPassword.Text;

            bool isTextboxFilled = Validator.IsPresent(txtLogin) && Validator.IsPresent(txtPassword);
            bool isUserValid=false;
            //validates textboxes using IsPresent
            if (isTextboxFilled)
            {
                //Loop through all users
                foreach (Users user in users)
                {
                    //Looking for a match between login and password for a user
                    if ((user.Login == login) && (user.Password == password))
                    {
                        //Switch: check user access property
                        switch (user.Access)
                        {
                            // true: this is an admin-open admin form sending in this admin
                            case true:
                                //cast user an an admin to access all data
                                Admin admin = (Admin)user;
                                AdminForm adminForm = new AdminForm(admin);
                                adminForm.ShowDialog();
                                break;
                            // false: this is a customer - must complete the captcha
                            case false:
                                //Open captcha form
                                Captcha captcha = new Captcha();
                                captcha.ShowDialog();

                                //captchaResult is set using the captcha tag so it must be done correctly
                                string captchaResult = (string)captcha.Tag;

                                //captcha is completed correctly
                                if (captchaResult == "correct")
                                {
                                    //cast user an a customer to access all data
                                    Customer customer = (Customer)user;
                                    CustomerForm userForm = new CustomerForm(customer);
                                    userForm.ShowDialog();
                                    
                                }
                                break;

                        }
                        
                        // set isUserValid true to avoid error on closing form after accessing
                        isUserValid = true;
                    }
                }//end of foreach
            }//end of IF
            //IsUserValid is false - display error that username and password are incorrect
            if (isUserValid==false  && isTextboxFilled== true)
            {
                MessageBox.Show("Incorrect Username or Password", "Error");
                txtLogin.Text = "";
                txtPassword.Text = "";
                txtLogin.Focus();
            }

            }//end if of login validator
           
        }
    }

