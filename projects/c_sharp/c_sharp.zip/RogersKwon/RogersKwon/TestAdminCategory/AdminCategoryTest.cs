using Microsoft.VisualStudio.TestTools.UnitTesting;
using RogersKwon; //saves time for referring to classes in that namespace

namespace TestAdminCategory
{
    [TestClass]
    public class AdminCategoryTest
    {
        [TestMethod]
        public void TestLevelJunior()
        {
            Admin admin = new Admin();
            int yearsAtCompanyExpected = 4, yearsAtCompanyActual;
            string catExpected = "Senior", catActual;

            admin.YearsAtCompany = 20;
            yearsAtCompanyActual = admin.YearsAtCompany;
            catActual = admin.Category;

            Assert.AreEqual(yearsAtCompanyExpected, yearsAtCompanyActual, "Invalid age Senior");
            Assert.AreEqual(catExpected, catActual, "You are not Senior");
        }
        [TestMethod]
        public void TestLevelIntermediate()
        {
            Admin admin = new Admin();
            int yearsAtCompanyExpected = 8, yearsAtCompanyActual;
            string catExpected = "Intermediate", catActual;

            admin.YearsAtCompany = 20;
            yearsAtCompanyActual = admin.YearsAtCompany;
            catActual = admin.Category;

            Assert.AreEqual(yearsAtCompanyExpected, yearsAtCompanyActual, "Invalid age Intermediate");
            Assert.AreEqual(catExpected, catActual, "You are not Intermediate");
        }
        [TestMethod]
        public void TestLevelSenior() 
        {
            Admin admin = new Admin();
            int yearsAtCompanyExpected = 15, yearsAtCompanyActual;
            string catExpected = "Senior", catActual;

            admin.YearsAtCompany = 2;
            yearsAtCompanyActual = admin.YearsAtCompany;
            catActual = admin.Category;

            Assert.AreEqual(yearsAtCompanyExpected, yearsAtCompanyActual, "Invalid age Intermediate");
            Assert.AreEqual(catExpected, catActual, "You are not Senior");
        }
    }
}