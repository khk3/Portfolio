﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RogersKwon
{
    //Written by Noah and Kang
    public partial class AdminForm : Form
    {
        // Class level Lists (products)
        List<Desktop> desktops = new List<Desktop>();
        List<Laptop> laptops = new List<Laptop>();
        List<Computer> inventory = new List<Computer>();

        public AdminForm() { }

        //Written by Kang
        //Sent: Admin
        //Returned: Nothing
        //Description: Reads xml files for products, Displays all to 2 seperate lists
        public AdminForm(Admin admin)//admin info sent after login
        {
            InitializeComponent();
            //store the user sent from loginForm to            
            lblAdminName.Text= admin.FirstName + " " + admin.LastName;
            lblHiringDate.Text = admin.HiredDate;
            lblYearsAtCompany.Text = admin.YearsAtCompany.ToString();
            lblCategory.Text = admin.Category;
            //store the lists of products
            desktops = CompanyDB.GetDesktops();
            laptops = CompanyDB.GetLaptops();
            inventory.AddRange(desktops);
            inventory.AddRange(laptops);

            DisplayProduct();
        }

        //Written by Kang
        //Method: DisplayProducts()
        //Sent: nothing
        //Returned: Nothing
        //Description: Displays all product info to the listboxes, clears whenever called
        private void DisplayProduct()
        {
            // Clear both listboxes if item was added
            lstDesktops.Items.Clear();
            lstLaptops.Items.Clear();

            // Add computers to list of items
            foreach (Desktop desktop in desktops)
            {
                lstDesktops.Items.Add(String.Format(
                    "{0,-15}{1,-10}{2,-10}{3,-10}{4,-15}{5,10}", "(" + desktop.GetType().Name + ")", desktop.InStock, desktop.Code, desktop.Brand, desktop.Model, desktop.Price.ToString("C2")));
            }
            foreach (Laptop laptop in laptops)
            {
                lstLaptops.Items.Add(String.Format(
                    "{0,-15}{1,-10}{2,-10}{3,-10}{4,-15}{5,10}", "(" + laptop.GetType().Name + ")", laptop.InStock,laptop.Code, laptop.Brand, laptop.Model, laptop.Price.ToString("C2")));
            }
        }//end of DisplayProduct


        //Written by Kang
        //lstDesktops index changed event
        //Description: Displays all product information of selection to all appropriate textboxes
        private void lstDesktops_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tbcAdmin.Controls[0] == tbcAdmin.SelectedTab && lstDesktops.SelectedIndex != -1)
            {     
                int index = lstDesktops.SelectedIndex;
                txtCode.Text = desktops[index].Code.ToString();
                txtBrand.Text = desktops[index].Brand.ToString();
                txtModel.Text = desktops[index].Model.ToString();
                txtProcessor.Text = desktops[index].Processor.ToString();
                txtRam.Text = desktops[index].Ram.ToString();
                txtProp1.Text = desktops[index].AllInOne.ToString();
                lblProp2.Text = "Graphic";
                txtProp2.Text = desktops[index].Graphic.ToString();
                txtPrice.Text = desktops[index].Price.ToString();
                txtInStock.Text= desktops[index].InStock.ToString();
            }       
        }

        //Written by Kang
        //lstLaptops index changed event
        //Description: Displays all product information of selection to all appropriate textboxes
        private void lstLaptops_SelectedIndexChanged(object sender, EventArgs e)
        {
            //lstDesktops.SelectedIndex = -1;
            if(tbcAdmin.Controls[1] == tbcAdmin.SelectedTab && lstLaptops.SelectedIndex !=-1)
            {
                int index = lstLaptops.SelectedIndex;
                txtCode.Text = laptops[index].Code.ToString();
                txtBrand.Text = laptops[index].Brand.ToString();
                txtModel.Text = laptops[index].Model.ToString();
                txtProcessor.Text = laptops[index].Processor.ToString();
                txtRam.Text = laptops[index].Ram.ToString();
                lblProp1.Text = "ScreenSize";
                txtProp1.Text = laptops[index].ScreenSize.ToString();
                lblProp2.Text = "Battery";
                txtProp2.Text = laptops[index].Battery.ToString();
                txtPrice.Text = laptops[index].Price.ToString();
                txtInStock.Text = laptops[index].InStock.ToString();
            }

        }//end of lstLaptops SelectedIndexChange  

        //Written by Kang
        //Update button click event
        //Description: determines which list is in use, admin is prompted if the wish to update prodcut information.
        //Calls update method for either Desktop or Laptop
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int indexD = lstDesktops.SelectedIndex; 
            int indexL= lstLaptops.SelectedIndex; 
            int code = Convert.ToInt32(txtCode.Text); 

            if (tbcAdmin.Controls[0] == tbcAdmin.SelectedTab && indexD!=-1)
            {
                //lstLaptops.SelectedIndex = -1;
                if (indexD!=-1 && desktops[indexD].Code== code)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Update?", "Confirm Update", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes && lstDesktops.SelectedIndex != -1)
                    {
                        UpdateDesktop();
                        //update desktop in XML file
                        CompanyDB.SaveDesktops(desktops);
                    }
                    
                    DisplayProduct();
                    ClearTextboxes();
                }
                else
                {
                    MessageBox.Show("Code doesn't match for an Update. Would you mean Add a new product?","Error");
                }

            }
            else if(tbcAdmin.Controls[1] == tbcAdmin.SelectedTab && indexL !=-1)
            {
                //lstDesktops.SelectedIndex =- 1;
                if(indexL!=-1 && laptops[indexL].Code == code)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Update?", "Confirm Update", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes && lstLaptops.SelectedIndex != -1)
                    {
                        UpdateLaptop();
                        //update laptop in XML file
                        CompanyDB.SaveLaptops(laptops);

                    }
                    DisplayProduct();
                    ClearTextboxes();
                }
                else
                {
                    MessageBox.Show("Code doesn't match for an Update. Would you mean Add a new product?", "Error");
                }
            }        
        }

        //Written by Kang
        //Method: UpDateDesktop()
        //Sent: nothing
        //Returned: Nothing
        //Description: Updates product information for a desktops using values entered by admin (from textboxes)
        private void UpdateDesktop()
        {
            int index = lstDesktops.SelectedIndex;
            desktops[index].Code = Convert.ToInt32(txtCode.Text);
            desktops[index].Brand = txtBrand.Text;
            desktops[index].Model = txtModel.Text;
            desktops[index].Processor = txtProcessor.Text;
            desktops[index].Ram = Convert.ToInt32(txtRam.Text);
            desktops[index].AllInOne = Convert.ToBoolean(txtProp1.Text);
            desktops[index].Graphic = txtProp2.Text;
            desktops[index].Price = Convert.ToDecimal(txtPrice.Text);
            desktops[index].InStock = Convert.ToInt32(txtInStock.Text);
        }

        //Written by Kang
        //Method: UpDateLaptop()
        //Sent: nothing
        //Returned: Nothing
        //Description: Updates product information for a Laptop using values entered by admin (from textboxes)
        private void UpdateLaptop()
        {
            int index = lstLaptops.SelectedIndex;
            laptops[index].Code = Convert.ToInt32(txtCode.Text);
            laptops[index].Brand = txtBrand.Text;
            laptops[index].Model = txtModel.Text;
            laptops[index].Processor = txtProcessor.Text;
            laptops[index].Ram = Convert.ToInt32(txtRam.Text);
            laptops[index].ScreenSize = Convert.ToDouble(txtProp1.Text);
            laptops[index].Battery = Convert.ToDouble(txtProp2.Text);
            laptops[index].Price = Convert.ToDecimal(txtPrice.Text);
            laptops[index].InStock = Convert.ToInt32(txtInStock.Text);
        }

        //Written by Kang
        //add button click event
        //Description: Adds a new Item to either Desktop or Laptop Prodcut List. Validates if code is already in use
        //Calls SaveDesktops // SaveLaptops to rewrite xml file, refreshes displays with new product information
        private void btnAdd_Click(object sender, EventArgs e)
        {   //if tab Desktop
            if (tbcAdmin.SelectedIndex==0)
            {
                if (ValidateDesktop())
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Add?", "Confirm Add", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Desktop newDesktop = new Desktop();
                        newDesktop.Code = Convert.ToInt32(txtCode.Text);
                        newDesktop.Brand = txtBrand.Text;
                        newDesktop.Model = txtModel.Text;
                        newDesktop.Processor = txtProcessor.Text;
                        newDesktop.Ram = Convert.ToInt32(txtRam.Text);
                        newDesktop.AllInOne = Convert.ToBoolean(txtProp1.Text);
                        newDesktop.Graphic = txtProp2.Text;
                        newDesktop.Price = Convert.ToDecimal(txtPrice.Text);
                        newDesktop.InStock= Convert.ToInt32(txtInStock.Text);

                        bool inList = false;
                        foreach(Desktop d in desktops)
                        {
                            if(d == newDesktop)// using the overloaded relational operator 
                            {
                                
                                inList = true;
                                txtInStock.Text= (d+newDesktop).ToString();//using overloaded math operator 
                            }
                                                     
                        }
                        if (inList == false)
                          desktops.Add(newDesktop);
                        //update desktop in XML file
                        CompanyDB.SaveDesktops(desktops);
                        //update the listboxes
                        DisplayProduct();
                        ClearTextboxes();
                    }                      
                }                  
            }
            //If tab Laptops
            else if (tbcAdmin.SelectedIndex == 1)
            {
                if (ValidateLaptop())
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Add?", "Confirm Add", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Laptop newLaptop = new Laptop();
                        newLaptop.Code = Convert.ToInt32(txtCode.Text);
                        newLaptop.Brand = txtBrand.Text;
                        newLaptop.Model = txtModel.Text;
                        newLaptop.Processor = txtProcessor.Text;
                        newLaptop.Ram = Convert.ToInt32(txtRam.Text);
                        newLaptop.ScreenSize = Convert.ToDouble(txtProp1.Text);
                        newLaptop.Battery = Convert.ToInt32(txtProp2.Text);
                        newLaptop.Price = Convert.ToDecimal(txtPrice.Text);

                        bool inList = false;
                        foreach (Laptop l in laptops)
                        {
                            if (l == newLaptop)
                            {                             
                                inList = true;
                                txtInStock.Text = (l + newLaptop).ToString(); //overload math operator +
                            }
                        }
                        if (inList == false)
                            laptops.Add(newLaptop);

                        CompanyDB.SaveLaptops(laptops);
                        DisplayProduct();
                        ClearTextboxes();
                    }                    
                }
            }
        }

        //Written by Kang
        //Method: ValidateDesktop()
        //Sent: Nothing
        //Returned: Bool
        //Description: Validates all textboxes meet requirements to add item to product list, calls ValidateCode
        private bool ValidateDesktop()
        {
            bool valid = false;
            if (Validator.IsPresent(txtCode) && Validator.IsPresent(txtBrand) && Validator.IsPresent(txtModel) &&
                Validator.IsPresent(txtProcessor) && Validator.IsPresent(txtRam) && Validator.IsPresent(txtProp1) &&
                Validator.IsPresent(txtProp2) && Validator.IsPresent(txtPrice) && Validator.IsInt32(txtCode) &&
                Validator.IsInt32(txtRam) && Validator.IsDecimal(txtPrice) && Validator.IsBool(txtProp1) &&
                Validator.IsInt32(txtInStock))
            {
                 valid = ValidateCode();
            }
            return valid;                                         
        }//end of validator Desktop

        //Written by Kang
        //Method: ValidateLaptop()
        //Sent: Nothing
        //Returned: Bool
        //Description: Validates all textboxes meet requirements to add item to product list, calls ValidateCode
        private bool ValidateLaptop()
        {
            bool valid = false;
            if (Validator.IsPresent(txtCode) && Validator.IsPresent(txtBrand) && Validator.IsPresent(txtModel) &&
                Validator.IsPresent(txtProcessor) && Validator.IsPresent(txtRam) && Validator.IsDouble(txtProp1) &&
                Validator.IsInt32(txtProp2) && Validator.IsPresent(txtPrice) && Validator.IsInt32(txtCode) &&
                Validator.IsInt32(txtRam) && Validator.IsDecimal(txtPrice)&& Validator.IsInt32(txtInStock))
            {
                valid = ValidateCode();
            }
            return valid;
        }

        //Written by Noah and Kang
        //Method: ValidateCode()
        //Sent: Nothing
        //Returned: Bool
        //Description: calls NoCodeRepeat, ensures code is unique. Error message if code in already in use
        private bool ValidateCode()
        {
            bool valid = false;
            switch (Validator.NoCodeRepeat(inventory, Convert.ToInt32(txtCode.Text)))
            {
                case true:
                    MessageBox.Show("This Product ID is already in use.\n" +
                                    "ID's must be unique acrosss all items", "Item ID error");
                    valid = false;
                    break;
                case false:
                    valid = true;
                    break;
            }
            return valid;
        }

        //Written by Kang
        //Method: Admin Tab index changed Event
        //Description: Changes Labels on Textboxes to reflect Product Properties of current tab selected
        private void tbcAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearTextboxes();
            if (tbcAdmin.Controls[0] == tbcAdmin.SelectedTab)
            {
                lblProp1.Text = "AllInOne";
                lblProp2.Text = "Graphics";
            }
            else if (tbcAdmin.Controls[1] == tbcAdmin.SelectedTab)
            {
                lblProp1.Text = "ScreenSize";
                lblProp2.Text = "Battery";
            }
        }

        //Written by Kang
        //Method: ClearTextBoxes()
        //Sent: Nothing
        //Returned: nothnig
        //Description: Sets all Textbox text to an empty string
        private void ClearTextboxes()
        {
            txtCode.Text = "";
            txtBrand.Text = "";
            txtModel.Text = "";
            txtProcessor.Text = "";
            txtProp1.Text = "";
            txtProp2.Text = "";
            txtPrice.Text = "";
            txtRam.Text = "";
            txtInStock.Text = "";          
        }

        //Written by Kang
        //Method: Remove button click Event
        //Description: Removes a prodcut at the Selected index, saves over xml file to reflect change, Refreshes Listboxes
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (tbcAdmin.Controls[0] == tbcAdmin.SelectedTab)
            {   //Remove only if there is more than 1
                if(lstDesktops.SelectedIndex != -1 && lstDesktops.Items.Count>1)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Remove?", "Confirm Remove", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        //remove the product from the list
                        desktops.RemoveAt(lstDesktops.SelectedIndex);
                        //save XML file with the new list
                        CompanyDB.SaveDesktops(desktops);
                        //display the list updated
                        DisplayProduct();
                    }                       
                }
            }
            else if (tbcAdmin.Controls[1] == tbcAdmin.SelectedTab)
            {   //Remove only if there is more than 1
                if (lstLaptops.SelectedIndex != -1 && lstLaptops.Items.Count>1)
                {
                    DialogResult result = MessageBox.Show("Would you like to Confirm Remove?", "Confirm Remove", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        //remove the product from the list
                        laptops.RemoveAt(lstLaptops.SelectedIndex);
                        //save XML file with the new list
                        CompanyDB.SaveLaptops(laptops);
                        //display the list updated
                        DisplayProduct();
                    }                   
                }
            }
        }//end of Remove Method            
    }//end of class
}
